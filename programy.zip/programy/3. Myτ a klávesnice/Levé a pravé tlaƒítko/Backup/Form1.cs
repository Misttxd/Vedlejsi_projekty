﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Levé_a_pravé_tlačítko
{
    public partial class oknoProgramu : Form
    {
        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void všechnyPrvky_MouseDown(object sender, MouseEventArgs e)
        {
            // Zvětši počitadlo levého tlačítka
            if (e.Button == MouseButtons.Left)
            {
                int kolikrát = Convert.ToInt32(poleLevéTlačítko.Text);
                kolikrát++;
                poleLevéTlačítko.Text = kolikrát.ToString();
            }

            // Zvětši počitadlo pravého tlačítka
            if (e.Button == MouseButtons.Right)
            {
                int kolikrát = Convert.ToInt32(polePravéTlačítko.Text);
                kolikrát++;
                polePravéTlačítko.Text = kolikrát.ToString();
            }
        }
    }
}
