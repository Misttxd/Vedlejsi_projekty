﻿namespace Levé_a_pravé_tlačítko
{
    partial class oknoProgramu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekLevéTlačítko = new System.Windows.Forms.Label();
            this.poleLevéTlačítko = new System.Windows.Forms.TextBox();
            this.popisekKrátLevé = new System.Windows.Forms.Label();
            this.popisekPravéTlačítko = new System.Windows.Forms.Label();
            this.polePravéTlačítko = new System.Windows.Forms.TextBox();
            this.popisekKrátPravé = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // popisekLevéTlačítko
            // 
            this.popisekLevéTlačítko.AutoSize = true;
            this.popisekLevéTlačítko.Location = new System.Drawing.Point(59, 34);
            this.popisekLevéTlačítko.Name = "popisekLevéTlačítko";
            this.popisekLevéTlačítko.Size = new System.Drawing.Size(73, 13);
            this.popisekLevéTlačítko.TabIndex = 0;
            this.popisekLevéTlačítko.Text = "&Levé tlačítko:";
            this.popisekLevéTlačítko.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            // 
            // poleLevéTlačítko
            // 
            this.poleLevéTlačítko.Location = new System.Drawing.Point(138, 31);
            this.poleLevéTlačítko.Name = "poleLevéTlačítko";
            this.poleLevéTlačítko.ReadOnly = true;
            this.poleLevéTlačítko.Size = new System.Drawing.Size(49, 20);
            this.poleLevéTlačítko.TabIndex = 1;
            this.poleLevéTlačítko.TabStop = false;
            this.poleLevéTlačítko.Text = "0";
            this.poleLevéTlačítko.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.poleLevéTlačítko.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            // 
            // popisekKrátLevé
            // 
            this.popisekKrátLevé.AutoSize = true;
            this.popisekKrátLevé.Location = new System.Drawing.Point(188, 34);
            this.popisekKrátLevé.Name = "popisekKrátLevé";
            this.popisekKrátLevé.Size = new System.Drawing.Size(28, 13);
            this.popisekKrátLevé.TabIndex = 2;
            this.popisekKrátLevé.Text = "-krát";
            this.popisekKrátLevé.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            // 
            // popisekPravéTlačítko
            // 
            this.popisekPravéTlačítko.AutoSize = true;
            this.popisekPravéTlačítko.Location = new System.Drawing.Point(59, 61);
            this.popisekPravéTlačítko.Name = "popisekPravéTlačítko";
            this.popisekPravéTlačítko.Size = new System.Drawing.Size(77, 13);
            this.popisekPravéTlačítko.TabIndex = 3;
            this.popisekPravéTlačítko.Text = "&Pravé tlačítko:";
            this.popisekPravéTlačítko.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            // 
            // polePravéTlačítko
            // 
            this.polePravéTlačítko.Location = new System.Drawing.Point(138, 58);
            this.polePravéTlačítko.Name = "polePravéTlačítko";
            this.polePravéTlačítko.ReadOnly = true;
            this.polePravéTlačítko.Size = new System.Drawing.Size(49, 20);
            this.polePravéTlačítko.TabIndex = 4;
            this.polePravéTlačítko.TabStop = false;
            this.polePravéTlačítko.Text = "0";
            this.polePravéTlačítko.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.polePravéTlačítko.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            // 
            // popisekKrátPravé
            // 
            this.popisekKrátPravé.AutoSize = true;
            this.popisekKrátPravé.Location = new System.Drawing.Point(188, 61);
            this.popisekKrátPravé.Name = "popisekKrátPravé";
            this.popisekKrátPravé.Size = new System.Drawing.Size(28, 13);
            this.popisekKrátPravé.TabIndex = 5;
            this.popisekKrátPravé.Text = "-krát";
            this.popisekKrátPravé.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            // 
            // oknoProgramu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(274, 108);
            this.Controls.Add(this.popisekKrátPravé);
            this.Controls.Add(this.popisekKrátLevé);
            this.Controls.Add(this.polePravéTlačítko);
            this.Controls.Add(this.poleLevéTlačítko);
            this.Controls.Add(this.popisekPravéTlačítko);
            this.Controls.Add(this.popisekLevéTlačítko);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "oknoProgramu";
            this.Text = "Levé a pravé tlačítko";
            this.Load += new System.EventHandler(this.oknoProgramu_Load);
            this.MouseDown += new System.Windows.Forms.MouseEventHandler(this.všechnyPrvky_MouseDown);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekLevéTlačítko;
        private System.Windows.Forms.TextBox poleLevéTlačítko;
        private System.Windows.Forms.Label popisekKrátLevé;
        private System.Windows.Forms.Label popisekPravéTlačítko;
        private System.Windows.Forms.TextBox polePravéTlačítko;
        private System.Windows.Forms.Label popisekKrátPravé;
    }
}

