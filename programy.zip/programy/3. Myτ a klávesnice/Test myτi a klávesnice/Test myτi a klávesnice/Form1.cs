﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Test_myši_a_klávesnice
{
    public partial class oknoTestMyšiKlávesnice : Form
    {
        public oknoTestMyšiKlávesnice()
        {
            InitializeComponent();
        }

        private void oknoTestMyšiKlávesnice_MouseDown(object sender, MouseEventArgs e)
        {
            string jaké;
            switch (e.Button)
            {
                case MouseButtons.Left:
                    jaké = "Levé";
                    break;
                case MouseButtons.Middle:
                    jaké = "prostřední";
                    break;
                case MouseButtons.Right:
                    jaké = "Pravé";
                    break;
                default:
                    jaké = "Neznámé";
                    break;
            }

            int myšX = e.X;
            int myšY = e.Y;

            info.Text = jaké + " tlačítko stisknuto na souřadnicích [" + myšX.ToString() + ";" + myšY.ToString() + "]";
        }

        private void oknoTestMyšiKlávesnice_KeyDown(object sender, KeyEventArgs e)
        {
            string modif = null;
            if (e.Control)
            {
                modif += "Ctrl+";
            }
            if (e.Alt)
            {
                modif += "Alt+";
            }
            if (e.Shift)
            {
                modif += "Shift+";
            }

            string klávesa;
            if (e.KeyCode == Keys.ControlKey || e.KeyCode == Keys.Menu || e.KeyCode == Keys.ShiftKey) {
                klávesa = null;
            }
            else{
                klávesa = e.KeyCode.ToString();
            }

            info.Text = "Stisknuta klávesa " + modif + klávesa;
                
        }

        private void oknoTestMyšiKlávesnice_Load(object sender, EventArgs e)
        {

        }
    }
}
