﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Klasifikace
{
    public partial class oknoKlasifiakce : Form
    {

        int index = 0;
        public oknoKlasifiakce()
        {
            InitializeComponent();
        }

        string[] jmena = new string[30];
        int[] znamky = new int[30];

        private void oknoKlasifiakce_Load(object sender, EventArgs e)
        {

        }

        private void tlačítkoVlož_Click(object sender, EventArgs e)
        {
            try
            {
                index = 0;

                int poradoveCislo = Convert.ToInt32(poleČíslo.Text);
                string jmenoStudenta = poleJméno.Text;
                int znamka = Convert.ToInt32(poleZnámka.Text);

                jmena[poradoveCislo - 1] = jmenoStudenta;
                znamky[poradoveCislo - 1] = znamka;
            }
            catch (Exception)
            {
                index = 1;
                MessageBox.Show("Zdané údaje nejsou ve správném formátu");

            }

            poleJméno.Text = null;
            poleZnámka.Text = null;
            poleČíslo.Text = null;

            if (index == 0)
            {
                MessageBox.Show("Údaj byl vložen do databáze");
            }
            else if (index == 1)
            {
                MessageBox.Show("Údaj nebyl vložen do databáze");
            }
        }

        private void tlačítkoZobraz_Click(object sender, EventArgs e)
        {
            string zprava = "";
            for (int i = 0; i < jmena.Length; i++)
            {
                if (jmena[i] != null)
                {
                    zprava += (i + 1).ToString() + ". " + jmena[i] + "    " + znamky[i] + Environment.NewLine;
                }
            }

            /*int i = 0;
            foreach (string jmeno in jmena)
            {   
                if (jmeno != null)
                {
                    {
                        zprava += (i+1).ToString() + ". " + jmeno + "    " + znamky[i] + Environment.NewLine ;
                    }
                }
                i++;

            }*/

            polePrehled.Text = zprava; 
        }
    }
}
