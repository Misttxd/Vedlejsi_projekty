﻿namespace Klasifikace
{
    partial class oknoKlasifiakce
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlačítkoZobraz = new System.Windows.Forms.Button();
            this.polePrehled = new System.Windows.Forms.TextBox();
            this.tlačítkoVlož = new System.Windows.Forms.Button();
            this.poleČíslo = new System.Windows.Forms.TextBox();
            this.poleZnámka = new System.Windows.Forms.TextBox();
            this.poleJméno = new System.Windows.Forms.TextBox();
            this.popisekČíslo = new System.Windows.Forms.Label();
            this.popisekJmnéno = new System.Windows.Forms.Label();
            this.popisekZnámka = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // tlačítkoZobraz
            // 
            this.tlačítkoZobraz.Location = new System.Drawing.Point(370, 46);
            this.tlačítkoZobraz.Name = "tlačítkoZobraz";
            this.tlačítkoZobraz.Size = new System.Drawing.Size(118, 46);
            this.tlačítkoZobraz.TabIndex = 0;
            this.tlačítkoZobraz.Text = "Zobraz";
            this.tlačítkoZobraz.UseVisualStyleBackColor = true;
            this.tlačítkoZobraz.Click += new System.EventHandler(this.tlačítkoZobraz_Click);
            // 
            // polePrehled
            // 
            this.polePrehled.Location = new System.Drawing.Point(505, 42);
            this.polePrehled.Multiline = true;
            this.polePrehled.Name = "polePrehled";
            this.polePrehled.ReadOnly = true;
            this.polePrehled.Size = new System.Drawing.Size(181, 292);
            this.polePrehled.TabIndex = 1;
            // 
            // tlačítkoVlož
            // 
            this.tlačítkoVlož.Location = new System.Drawing.Point(25, 46);
            this.tlačítkoVlož.Name = "tlačítkoVlož";
            this.tlačítkoVlož.Size = new System.Drawing.Size(121, 46);
            this.tlačítkoVlož.TabIndex = 2;
            this.tlačítkoVlož.Text = "Vlož záznam";
            this.tlačítkoVlož.UseVisualStyleBackColor = true;
            this.tlačítkoVlož.Click += new System.EventHandler(this.tlačítkoVlož_Click);
            // 
            // poleČíslo
            // 
            this.poleČíslo.Location = new System.Drawing.Point(25, 161);
            this.poleČíslo.Name = "poleČíslo";
            this.poleČíslo.Size = new System.Drawing.Size(75, 20);
            this.poleČíslo.TabIndex = 3;
            // 
            // poleZnámka
            // 
            this.poleZnámka.Location = new System.Drawing.Point(234, 161);
            this.poleZnámka.Name = "poleZnámka";
            this.poleZnámka.Size = new System.Drawing.Size(78, 20);
            this.poleZnámka.TabIndex = 4;
            // 
            // poleJméno
            // 
            this.poleJméno.Location = new System.Drawing.Point(130, 161);
            this.poleJméno.Name = "poleJméno";
            this.poleJméno.Size = new System.Drawing.Size(75, 20);
            this.poleJméno.TabIndex = 5;
            // 
            // popisekČíslo
            // 
            this.popisekČíslo.AutoSize = true;
            this.popisekČíslo.Location = new System.Drawing.Point(22, 136);
            this.popisekČíslo.Name = "popisekČíslo";
            this.popisekČíslo.Size = new System.Drawing.Size(83, 13);
            this.popisekČíslo.TabIndex = 6;
            this.popisekČíslo.Text = "Pořadové číslo:";
            // 
            // popisekJmnéno
            // 
            this.popisekJmnéno.AutoSize = true;
            this.popisekJmnéno.Location = new System.Drawing.Point(127, 136);
            this.popisekJmnéno.Name = "popisekJmnéno";
            this.popisekJmnéno.Size = new System.Drawing.Size(85, 13);
            this.popisekJmnéno.TabIndex = 7;
            this.popisekJmnéno.Text = "Jméno studenta:";
            // 
            // popisekZnámka
            // 
            this.popisekZnámka.AutoSize = true;
            this.popisekZnámka.Location = new System.Drawing.Point(231, 136);
            this.popisekZnámka.Name = "popisekZnámka";
            this.popisekZnámka.Size = new System.Drawing.Size(49, 13);
            this.popisekZnámka.TabIndex = 8;
            this.popisekZnámka.Text = "Známka:";
            // 
            // oknoKlasifiakce
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.popisekZnámka);
            this.Controls.Add(this.popisekJmnéno);
            this.Controls.Add(this.popisekČíslo);
            this.Controls.Add(this.poleJméno);
            this.Controls.Add(this.poleZnámka);
            this.Controls.Add(this.poleČíslo);
            this.Controls.Add(this.tlačítkoVlož);
            this.Controls.Add(this.polePrehled);
            this.Controls.Add(this.tlačítkoZobraz);
            this.Name = "oknoKlasifiakce";
            this.Text = "Klasifikace";
            this.Load += new System.EventHandler(this.oknoKlasifiakce_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tlačítkoZobraz;
        private System.Windows.Forms.TextBox polePrehled;
        private System.Windows.Forms.Button tlačítkoVlož;
        private System.Windows.Forms.TextBox poleČíslo;
        private System.Windows.Forms.TextBox poleZnámka;
        private System.Windows.Forms.TextBox poleJméno;
        private System.Windows.Forms.Label popisekČíslo;
        private System.Windows.Forms.Label popisekJmnéno;
        private System.Windows.Forms.Label popisekZnámka;
    }
}

