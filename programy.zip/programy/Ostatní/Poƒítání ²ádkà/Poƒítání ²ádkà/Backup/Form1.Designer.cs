﻿namespace Počítání_řádků
{
    partial class oknoProgramu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekJménoSouboru = new System.Windows.Forms.Label();
            this.poleJménoSouboru = new System.Windows.Forms.TextBox();
            this.tlačítkoProcházet = new System.Windows.Forms.Button();
            this.tlačítkoSpočtiŘádky = new System.Windows.Forms.Button();
            this.oknoOtevřeníSouboru = new System.Windows.Forms.OpenFileDialog();
            this.SuspendLayout();
            // 
            // popisekJménoSouboru
            // 
            this.popisekJménoSouboru.AutoSize = true;
            this.popisekJménoSouboru.Location = new System.Drawing.Point(10, 20);
            this.popisekJménoSouboru.Name = "popisekJménoSouboru";
            this.popisekJménoSouboru.Size = new System.Drawing.Size(82, 13);
            this.popisekJménoSouboru.TabIndex = 0;
            this.popisekJménoSouboru.Text = "&Jméno souboru:";
            // 
            // poleJménoSouboru
            // 
            this.poleJménoSouboru.Location = new System.Drawing.Point(13, 37);
            this.poleJménoSouboru.Name = "poleJménoSouboru";
            this.poleJménoSouboru.Size = new System.Drawing.Size(209, 20);
            this.poleJménoSouboru.TabIndex = 1;
            // 
            // tlačítkoProcházet
            // 
            this.tlačítkoProcházet.Location = new System.Drawing.Point(237, 35);
            this.tlačítkoProcházet.Name = "tlačítkoProcházet";
            this.tlačítkoProcházet.Size = new System.Drawing.Size(91, 23);
            this.tlačítkoProcházet.TabIndex = 2;
            this.tlačítkoProcházet.Text = "P&rocházet ...";
            this.tlačítkoProcházet.UseVisualStyleBackColor = true;
            this.tlačítkoProcházet.Click += new System.EventHandler(this.tlačítkoProcházet_Click);
            // 
            // tlačítkoSpočtiŘádky
            // 
            this.tlačítkoSpočtiŘádky.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tlačítkoSpočtiŘádky.Location = new System.Drawing.Point(95, 73);
            this.tlačítkoSpočtiŘádky.Name = "tlačítkoSpočtiŘádky";
            this.tlačítkoSpočtiŘádky.Size = new System.Drawing.Size(149, 48);
            this.tlačítkoSpočtiŘádky.TabIndex = 4;
            this.tlačítkoSpočtiŘádky.Text = "&Spočti řádky";
            this.tlačítkoSpočtiŘádky.UseVisualStyleBackColor = true;
            this.tlačítkoSpočtiŘádky.Click += new System.EventHandler(this.tlačítkoSpočtiŘádky_Click);
            // 
            // oknoOtevřeníSouboru
            // 
            this.oknoOtevřeníSouboru.FileName = "openFileDialog1";
            // 
            // oknoProgramu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(339, 140);
            this.Controls.Add(this.tlačítkoSpočtiŘádky);
            this.Controls.Add(this.tlačítkoProcházet);
            this.Controls.Add(this.poleJménoSouboru);
            this.Controls.Add(this.popisekJménoSouboru);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "oknoProgramu";
            this.Text = "Počítání řádků";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekJménoSouboru;
        private System.Windows.Forms.TextBox poleJménoSouboru;
        private System.Windows.Forms.Button tlačítkoProcházet;
        private System.Windows.Forms.Button tlačítkoSpočtiŘádky;
        private System.Windows.Forms.OpenFileDialog oknoOtevřeníSouboru;
    }
}

