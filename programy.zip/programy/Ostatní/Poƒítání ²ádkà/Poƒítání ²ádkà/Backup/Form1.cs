﻿using System;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace Počítání_řádků
{
    public partial class oknoProgramu : Form
    {
        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void tlačítkoSpočtiŘádky_Click(object sender, EventArgs e)
        {
            // Otevření souboru
            string jménoSouboru = poleJménoSouboru.Text;
            StreamReader soubor = new StreamReader(jménoSouboru, Encoding.Default);

            // Počitadlo
            int početŘádků = 0;

            // Čtení až do konce souboru
            while (soubor.ReadLine() != null)
                početŘádků++;

            // Zavření souboru a zobrazení výsledku
            soubor.Close();
            MessageBox.Show("Soubor má " + početŘádků.ToString() + " řádků");
        }

        private void tlačítkoProcházet_Click(object sender, EventArgs e)
        {
            DialogResult odpověď = oknoOtevřeníSouboru.ShowDialog();
            if (odpověď == DialogResult.OK)
                poleJménoSouboru.Text = oknoOtevřeníSouboru.FileName;
        }
    }
}
