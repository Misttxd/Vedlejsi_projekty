﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace Rainman
{
    public partial class oknoProgramu : Form
    {
        int doba = 500; // kolik milisekund budou puntíky vidět
        bool ukaž = false;
        int početPuntíků, velikostPuntíku;
        Random náhoda = new Random();

        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {
            if (!ukaž) return;
            Graphics kp = e.Graphics;

            // Nakresli puntíky
            int maxX = panel.ClientSize.Width  - velikostPuntíku;
            int maxY = panel.ClientSize.Height - velikostPuntíku;
            for (int puntík = 0; puntík < početPuntíků; puntík++)
            {
                int x = náhoda.Next(0, maxX);
                int y = náhoda.Next(0, maxY);
                kp.FillEllipse(Brushes.CornflowerBlue,
                    x, y, velikostPuntíku, velikostPuntíku);
            }
        }

        private void tlačítkoUkaž_Click(object sender, EventArgs e)
        {
            // Náhodně urči počet puntíků
            int maxPočet;
            if (políčkoTěžká.Checked)
            {
                maxPočet = 499; velikostPuntíku = 6;
            }
            else
            {
                maxPočet = 9; velikostPuntíku = 20;
            }
            početPuntíků = náhoda.Next(1, maxPočet + 1);

            // Na chvíli ukaž
            ukaž = true;
            panel.Refresh();
            System.Threading.Thread.Sleep(doba);
            ukaž = false;
            panel.Refresh();

            // Zablokuj/odblokuj ovládací prvky
            políčkoTěžká.Enabled = false;
            tlačítkoUkaž.Enabled = false;
            popisekKolik.Enabled = true;
            poleKolik.Enabled = true;
            tlačítkoVyhodnoť.Enabled = true;

            poleKolik.Text = null;
        }

        private void tlačítkoVyhodnoť_Click(object sender, EventArgs e)
        {
            try
            {
                // Vyhodnoť uživatelův odhad
                int odhad = Convert.ToInt32(poleKolik.Text);
                int chyba = Math.Abs(odhad - početPuntíků);
                if (chyba == 0)
                    MessageBox.Show("SPRÁVNĚ!");
                else
                    MessageBox.Show("Spletl(a) jste se o " + chyba.ToString());

                // Zablokuj/odblokuj ovládací prvky
                políčkoTěžká.Enabled = true;
                tlačítkoUkaž.Enabled = true;
                popisekKolik.Enabled = false;
                poleKolik.Enabled = false;
                tlačítkoVyhodnoť.Enabled = false;
            }
            catch
            {
                MessageBox.Show("Zadána nekorektní hodnota");
            }
        }
    }
}