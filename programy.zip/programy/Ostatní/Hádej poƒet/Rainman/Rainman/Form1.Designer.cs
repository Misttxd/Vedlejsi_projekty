﻿namespace Rainman
{
    partial class oknoProgramu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.políčkoTěžká = new System.Windows.Forms.CheckBox();
            this.tlačítkoUkaž = new System.Windows.Forms.Button();
            this.popisekKolik = new System.Windows.Forms.Label();
            this.poleKolik = new System.Windows.Forms.TextBox();
            this.tlačítkoVyhodnoť = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.panel.Location = new System.Drawing.Point(18, 18);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(328, 100);
            this.panel.TabIndex = 0;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
            // 
            // políčkoTěžká
            // 
            this.políčkoTěžká.AutoSize = true;
            this.políčkoTěžká.Location = new System.Drawing.Point(37, 134);
            this.políčkoTěžká.Name = "políčkoTěžká";
            this.políčkoTěžká.Size = new System.Drawing.Size(92, 17);
            this.políčkoTěžká.TabIndex = 1;
            this.políčkoTěžká.Text = "&Těžká úroveň";
            this.políčkoTěžká.UseVisualStyleBackColor = true;
            // 
            // tlačítkoUkaž
            // 
            this.tlačítkoUkaž.Location = new System.Drawing.Point(18, 158);
            this.tlačítkoUkaž.Name = "tlačítkoUkaž";
            this.tlačítkoUkaž.Size = new System.Drawing.Size(131, 23);
            this.tlačítkoUkaž.TabIndex = 2;
            this.tlačítkoUkaž.Text = "&Ukaž";
            this.tlačítkoUkaž.UseVisualStyleBackColor = true;
            this.tlačítkoUkaž.Click += new System.EventHandler(this.tlačítkoUkaž_Click);
            // 
            // popisekKolik
            // 
            this.popisekKolik.AutoSize = true;
            this.popisekKolik.Enabled = false;
            this.popisekKolik.Location = new System.Drawing.Point(212, 134);
            this.popisekKolik.Name = "popisekKolik";
            this.popisekKolik.Size = new System.Drawing.Size(77, 13);
            this.popisekKolik.TabIndex = 3;
            this.popisekKolik.Text = "&Kolik jich bylo?";
            // 
            // poleKolik
            // 
            this.poleKolik.Enabled = false;
            this.poleKolik.Location = new System.Drawing.Point(295, 132);
            this.poleKolik.Name = "poleKolik";
            this.poleKolik.Size = new System.Drawing.Size(51, 20);
            this.poleKolik.TabIndex = 4;
            this.poleKolik.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tlačítkoVyhodnoť
            // 
            this.tlačítkoVyhodnoť.Enabled = false;
            this.tlačítkoVyhodnoť.Location = new System.Drawing.Point(215, 158);
            this.tlačítkoVyhodnoť.Name = "tlačítkoVyhodnoť";
            this.tlačítkoVyhodnoť.Size = new System.Drawing.Size(131, 23);
            this.tlačítkoVyhodnoť.TabIndex = 5;
            this.tlačítkoVyhodnoť.Text = "&Vyhodnoť";
            this.tlačítkoVyhodnoť.UseVisualStyleBackColor = true;
            this.tlačítkoVyhodnoť.Click += new System.EventHandler(this.tlačítkoVyhodnoť_Click);
            // 
            // oknoProgramu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(364, 199);
            this.Controls.Add(this.tlačítkoVyhodnoť);
            this.Controls.Add(this.poleKolik);
            this.Controls.Add(this.popisekKolik);
            this.Controls.Add(this.tlačítkoUkaž);
            this.Controls.Add(this.políčkoTěžká);
            this.Controls.Add(this.panel);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "oknoProgramu";
            this.Text = "Hádej počet";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.CheckBox políčkoTěžká;
        private System.Windows.Forms.Button tlačítkoUkaž;
        private System.Windows.Forms.Label popisekKolik;
        private System.Windows.Forms.TextBox poleKolik;
        private System.Windows.Forms.Button tlačítkoVyhodnoť;
    }
}

