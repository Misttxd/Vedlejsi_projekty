﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Bludiště
{
    public partial class oknoBludiště : Form
    {
        int ticks;
        int best_time = int.MaxValue;
        public oknoBludiště()
        {
            InitializeComponent();
        }

        private void tlačítka_MouseEnter(object sender, EventArgs e)
        {
            timer.Enabled = false;
            MessageBox.Show("Zkus to znovu", "Konec hry", MessageBoxButtons.OK, MessageBoxIcon.Error);
            tlačítko1.Enabled = false;
            tlačítko2.Enabled = false;
            tlačítko3.Enabled = false;
            tlačítko4.Enabled = false;
            poličkoEnd.Enabled = false;
            popisekStopky.Text = "čas: 0";
            ticks = 0;
        }

        private void poličkoEnd_CheckedChanged(object sender, EventArgs e)
        {
            timer.Enabled = false;
            MessageBox.Show("Vyhrál jsi, tvůj čas: "+ ticks.ToString() + " s");
            tlačítko1.Enabled = false;
            tlačítko2.Enabled = false;
            tlačítko3.Enabled = false;
            tlačítko4.Enabled = false;
            poličkoEnd.Enabled = false;
            popisekStopky.Text = "čas: 0";
            if (ticks < best_time)
            {
                best_time = ticks;
            }
            ticks = 0;
            popisekNejlepšíČas.Text = "Nejlepší čas: " + best_time.ToString() + " s";
            
        }

        private void tlačítkoStart_Click(object sender, EventArgs e)
        {
            timer.Enabled = true;
            tlačítko1.Enabled = true;
            tlačítko2.Enabled = true;
            tlačítko3.Enabled = true;
            tlačítko4.Enabled = true;
            poličkoEnd.Enabled = true;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            ticks++;
            popisekStopky.Text = "čas: " + ticks.ToString();
        }

        private void tlačítkoBarva_Click(object sender, EventArgs e)
        {
            DialogResult dr = colorDialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                tlačítko1.BackColor = colorDialog.Color;
                tlačítko2.BackColor = colorDialog.Color;
                tlačítko3.BackColor = colorDialog.Color;
                tlačítko4.BackColor = colorDialog.Color;
            }
            else
            {
                MessageBox.Show("Bazva beze změny.");
            }
        }

        private void oknoBludiště_Load(object sender, EventArgs e)
        {

        }

        private void tlačítkoKonec_Click(object sender, EventArgs e)
        {
            DialogResult dr = MessageBox.Show("Přeje si ukončit hru?", "Konec hry", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (dr == DialogResult.Yes)
            {
                Close();
            }
        }

        private void tlačítko2_Click(object sender, EventArgs e)
        {

        }

        private void tlačítkoPísmo_Click(object sender, EventArgs e)
        {
            DialogResult dr = fontDialog.ShowDialog();
            if (dr == DialogResult.OK)
            {
                tlačítkoKonec.Font = fontDialog.Font;
                tlačítkoPísmo.Font = fontDialog.Font;
                tlačítkoStart.Font = fontDialog.Font;
                tlačítkoKonec.Font = fontDialog.Font;
                tlačítkoBarva.Font = fontDialog.Font;
            }
        }
    }
}
