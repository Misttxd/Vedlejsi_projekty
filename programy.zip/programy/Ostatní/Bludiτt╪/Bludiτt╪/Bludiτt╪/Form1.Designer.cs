﻿namespace Bludiště
{
    partial class oknoBludiště
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.tlačítko2 = new System.Windows.Forms.Button();
            this.tlačítko3 = new System.Windows.Forms.Button();
            this.tlačítko1 = new System.Windows.Forms.Button();
            this.poličkoEnd = new System.Windows.Forms.CheckBox();
            this.tlačítko4 = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.tlačítkoStart = new System.Windows.Forms.Button();
            this.popisekStopky = new System.Windows.Forms.Label();
            this.popisekNejlepšíČas = new System.Windows.Forms.Label();
            this.colorDialog = new System.Windows.Forms.ColorDialog();
            this.tlačítkoBarva = new System.Windows.Forms.Button();
            this.tlačítkoKonec = new System.Windows.Forms.Button();
            this.tlačítkoPísmo = new System.Windows.Forms.Button();
            this.fontDialog = new System.Windows.Forms.FontDialog();
            this.SuspendLayout();
            // 
            // tlačítko2
            // 
            this.tlačítko2.Enabled = false;
            this.tlačítko2.Location = new System.Drawing.Point(25, 36);
            this.tlačítko2.Name = "tlačítko2";
            this.tlačítko2.Size = new System.Drawing.Size(91, 223);
            this.tlačítko2.TabIndex = 0;
            this.tlačítko2.TabStop = false;
            this.tlačítko2.UseVisualStyleBackColor = true;
            this.tlačítko2.Click += new System.EventHandler(this.tlačítko2_Click);
            this.tlačítko2.MouseEnter += new System.EventHandler(this.tlačítka_MouseEnter);
            // 
            // tlačítko3
            // 
            this.tlačítko3.Enabled = false;
            this.tlačítko3.Location = new System.Drawing.Point(145, 36);
            this.tlačítko3.Name = "tlačítko3";
            this.tlačítko3.Size = new System.Drawing.Size(91, 223);
            this.tlačítko3.TabIndex = 1;
            this.tlačítko3.TabStop = false;
            this.tlačítko3.UseVisualStyleBackColor = true;
            this.tlačítko3.MouseEnter += new System.EventHandler(this.tlačítka_MouseEnter);
            // 
            // tlačítko1
            // 
            this.tlačítko1.Enabled = false;
            this.tlačítko1.Location = new System.Drawing.Point(25, 8);
            this.tlačítko1.Name = "tlačítko1";
            this.tlačítko1.Size = new System.Drawing.Size(211, 31);
            this.tlačítko1.TabIndex = 2;
            this.tlačítko1.TabStop = false;
            this.tlačítko1.UseVisualStyleBackColor = true;
            this.tlačítko1.MouseEnter += new System.EventHandler(this.tlačítka_MouseEnter);
            // 
            // poličkoEnd
            // 
            this.poličkoEnd.AutoSize = true;
            this.poličkoEnd.Enabled = false;
            this.poličkoEnd.Location = new System.Drawing.Point(122, 45);
            this.poličkoEnd.Name = "poličkoEnd";
            this.poličkoEnd.Size = new System.Drawing.Size(15, 14);
            this.poličkoEnd.TabIndex = 3;
            this.poličkoEnd.UseVisualStyleBackColor = true;
            this.poličkoEnd.CheckedChanged += new System.EventHandler(this.poličkoEnd_CheckedChanged);
            // 
            // tlačítko4
            // 
            this.tlačítko4.Enabled = false;
            this.tlačítko4.Location = new System.Drawing.Point(25, 279);
            this.tlačítko4.Name = "tlačítko4";
            this.tlačítko4.Size = new System.Drawing.Size(211, 55);
            this.tlačítko4.TabIndex = 4;
            this.tlačítko4.TabStop = false;
            this.tlačítko4.UseVisualStyleBackColor = true;
            this.tlačítko4.MouseEnter += new System.EventHandler(this.tlačítka_MouseEnter);
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // tlačítkoStart
            // 
            this.tlačítkoStart.Location = new System.Drawing.Point(268, 12);
            this.tlačítkoStart.Margin = new System.Windows.Forms.Padding(2, 2, 2, 2);
            this.tlačítkoStart.Name = "tlačítkoStart";
            this.tlačítkoStart.Size = new System.Drawing.Size(98, 45);
            this.tlačítkoStart.TabIndex = 5;
            this.tlačítkoStart.Text = "Start";
            this.tlačítkoStart.UseVisualStyleBackColor = true;
            this.tlačítkoStart.Click += new System.EventHandler(this.tlačítkoStart_Click);
            // 
            // popisekStopky
            // 
            this.popisekStopky.AutoSize = true;
            this.popisekStopky.Location = new System.Drawing.Point(265, 78);
            this.popisekStopky.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.popisekStopky.Name = "popisekStopky";
            this.popisekStopky.Size = new System.Drawing.Size(36, 13);
            this.popisekStopky.TabIndex = 6;
            this.popisekStopky.Text = "čas: 0";
            // 
            // popisekNejlepšíČas
            // 
            this.popisekNejlepšíČas.AutoSize = true;
            this.popisekNejlepšíČas.Location = new System.Drawing.Point(265, 110);
            this.popisekNejlepšíČas.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.popisekNejlepšíČas.Name = "popisekNejlepšíČas";
            this.popisekNejlepšíČas.Size = new System.Drawing.Size(0, 13);
            this.popisekNejlepšíČas.TabIndex = 7;
            // 
            // tlačítkoBarva
            // 
            this.tlačítkoBarva.Location = new System.Drawing.Point(268, 212);
            this.tlačítkoBarva.Name = "tlačítkoBarva";
            this.tlačítkoBarva.Size = new System.Drawing.Size(98, 42);
            this.tlačítkoBarva.TabIndex = 8;
            this.tlačítkoBarva.Text = "Změň barvu";
            this.tlačítkoBarva.UseVisualStyleBackColor = true;
            this.tlačítkoBarva.Click += new System.EventHandler(this.tlačítkoBarva_Click);
            // 
            // tlačítkoKonec
            // 
            this.tlačítkoKonec.Location = new System.Drawing.Point(268, 279);
            this.tlačítkoKonec.Name = "tlačítkoKonec";
            this.tlačítkoKonec.Size = new System.Drawing.Size(98, 55);
            this.tlačítkoKonec.TabIndex = 11;
            this.tlačítkoKonec.Text = "Konec hry";
            this.tlačítkoKonec.UseVisualStyleBackColor = true;
            this.tlačítkoKonec.Click += new System.EventHandler(this.tlačítkoKonec_Click);
            // 
            // tlačítkoPísmo
            // 
            this.tlačítkoPísmo.Location = new System.Drawing.Point(271, 151);
            this.tlačítkoPísmo.Name = "tlačítkoPísmo";
            this.tlačítkoPísmo.Size = new System.Drawing.Size(95, 43);
            this.tlačítkoPísmo.TabIndex = 12;
            this.tlačítkoPísmo.Text = "Změň písmo";
            this.tlačítkoPísmo.UseVisualStyleBackColor = true;
            this.tlačítkoPísmo.Click += new System.EventHandler(this.tlačítkoPísmo_Click);
            // 
            // oknoBludiště
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(393, 390);
            this.Controls.Add(this.tlačítkoPísmo);
            this.Controls.Add(this.tlačítkoKonec);
            this.Controls.Add(this.tlačítkoBarva);
            this.Controls.Add(this.popisekNejlepšíČas);
            this.Controls.Add(this.popisekStopky);
            this.Controls.Add(this.tlačítkoStart);
            this.Controls.Add(this.tlačítko4);
            this.Controls.Add(this.poličkoEnd);
            this.Controls.Add(this.tlačítko1);
            this.Controls.Add(this.tlačítko3);
            this.Controls.Add(this.tlačítko2);
            this.Name = "oknoBludiště";
            this.Text = "Bludiště";
            this.Load += new System.EventHandler(this.oknoBludiště_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tlačítko2;
        private System.Windows.Forms.Button tlačítko3;
        private System.Windows.Forms.Button tlačítko1;
        private System.Windows.Forms.CheckBox poličkoEnd;
        private System.Windows.Forms.Button tlačítko4;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.Button tlačítkoStart;
        private System.Windows.Forms.Label popisekStopky;
        private System.Windows.Forms.Label popisekNejlepšíČas;
        private System.Windows.Forms.ColorDialog colorDialog;
        private System.Windows.Forms.Button tlačítkoBarva;
        private System.Windows.Forms.Button tlačítkoKonec;
        private System.Windows.Forms.Button tlačítkoPísmo;
        private System.Windows.Forms.FontDialog fontDialog;
    }
}

