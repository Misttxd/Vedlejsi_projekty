﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tisíc_teček
{
    public partial class oknoTisícTeček : Form
    {
        Random náhoda = new Random();

        public oknoTisícTeček()
        {
            InitializeComponent();
        }

        private void oknoTisícTeček_Paint(object sender, PaintEventArgs e)
        {
            Graphics kreslícíPlocha = e.Graphics;

            int maxX = ClientSize.Width -1;
            int maxY = ClientSize.Height - 1;

            for (int početTeček = 0; početTeček < 1000; početTeček++)
            {
                int x = náhoda.Next(0, maxX+1);
                int y = náhoda.Next(0, maxY +1);

                kreslícíPlocha.FillRectangle(Brushes.White, x, y, 1 ,1);
 
            }
        }
    }
}
