﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DPH
{
    public partial class oknoDPH : Form
    {
        public oknoDPH()
        {
            InitializeComponent();
        }

        private void tlačítkoVypočti_Click(object sender, EventArgs e)
        {
            try
            {
                double cena = Convert.ToDouble(poleCena.Text);
                double sazba = Convert.ToDouble(poleSazbaDPH.Text);

                double dělitel = 1 + sazba / 100;
                double cenaBezDPH = cena / dělitel;
                double DPH = cena - cenaBezDPH;

                poleBezDPH.Text = cenaBezDPH.ToString("F2");
                poleDPH.Text = DPH.ToString("F2");
            }
            catch (Exception)
            {
                MessageBox.Show("Zadán nekorektní údaj");
            }
        }
    }
}
