﻿namespace DPH
{
    partial class oknoDPH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekCenaSDPH = new System.Windows.Forms.Label();
            this.popisekSazbaDPH = new System.Windows.Forms.Label();
            this.popisekCenaBezDPH = new System.Windows.Forms.Label();
            this.popisekDPH = new System.Windows.Forms.Label();
            this.popisekKčSDPH = new System.Windows.Forms.Label();
            this.popisekProcenta = new System.Windows.Forms.Label();
            this.popisekKčBezDPH = new System.Windows.Forms.Label();
            this.popisekKčDPH = new System.Windows.Forms.Label();
            this.poleCena = new System.Windows.Forms.TextBox();
            this.poleSazbaDPH = new System.Windows.Forms.TextBox();
            this.tlačítkoVypočti = new System.Windows.Forms.Button();
            this.poleBezDPH = new System.Windows.Forms.TextBox();
            this.poleDPH = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // popisekCenaSDPH
            // 
            this.popisekCenaSDPH.AutoSize = true;
            this.popisekCenaSDPH.Location = new System.Drawing.Point(86, 50);
            this.popisekCenaSDPH.Name = "popisekCenaSDPH";
            this.popisekCenaSDPH.Size = new System.Drawing.Size(120, 17);
            this.popisekCenaSDPH.TabIndex = 0;
            this.popisekCenaSDPH.Text = "&Cena včetně DPH";
            // 
            // popisekSazbaDPH
            // 
            this.popisekSazbaDPH.AutoSize = true;
            this.popisekSazbaDPH.Location = new System.Drawing.Point(86, 117);
            this.popisekSazbaDPH.Name = "popisekSazbaDPH";
            this.popisekSazbaDPH.Size = new System.Drawing.Size(81, 17);
            this.popisekSazbaDPH.TabIndex = 1;
            this.popisekSazbaDPH.Text = "Sazba DPH";
            // 
            // popisekCenaBezDPH
            // 
            this.popisekCenaBezDPH.AutoSize = true;
            this.popisekCenaBezDPH.Location = new System.Drawing.Point(86, 229);
            this.popisekCenaBezDPH.Name = "popisekCenaBezDPH";
            this.popisekCenaBezDPH.Size = new System.Drawing.Size(101, 17);
            this.popisekCenaBezDPH.TabIndex = 2;
            this.popisekCenaBezDPH.Text = "Cena bez DPH";
            // 
            // popisekDPH
            // 
            this.popisekDPH.AutoSize = true;
            this.popisekDPH.Location = new System.Drawing.Point(86, 276);
            this.popisekDPH.Name = "popisekDPH";
            this.popisekDPH.Size = new System.Drawing.Size(37, 17);
            this.popisekDPH.TabIndex = 3;
            this.popisekDPH.Text = "DPH";
            // 
            // popisekKčSDPH
            // 
            this.popisekKčSDPH.AutoSize = true;
            this.popisekKčSDPH.Location = new System.Drawing.Point(404, 50);
            this.popisekKčSDPH.Name = "popisekKčSDPH";
            this.popisekKčSDPH.Size = new System.Drawing.Size(24, 17);
            this.popisekKčSDPH.TabIndex = 4;
            this.popisekKčSDPH.Text = "Kč";
            // 
            // popisekProcenta
            // 
            this.popisekProcenta.AutoSize = true;
            this.popisekProcenta.Location = new System.Drawing.Point(404, 117);
            this.popisekProcenta.Name = "popisekProcenta";
            this.popisekProcenta.Size = new System.Drawing.Size(20, 17);
            this.popisekProcenta.TabIndex = 5;
            this.popisekProcenta.Text = "%";
            // 
            // popisekKčBezDPH
            // 
            this.popisekKčBezDPH.AutoSize = true;
            this.popisekKčBezDPH.Location = new System.Drawing.Point(404, 229);
            this.popisekKčBezDPH.Name = "popisekKčBezDPH";
            this.popisekKčBezDPH.Size = new System.Drawing.Size(24, 17);
            this.popisekKčBezDPH.TabIndex = 6;
            this.popisekKčBezDPH.Text = "Kč";
            // 
            // popisekKčDPH
            // 
            this.popisekKčDPH.AutoSize = true;
            this.popisekKčDPH.Location = new System.Drawing.Point(404, 276);
            this.popisekKčDPH.Name = "popisekKčDPH";
            this.popisekKčDPH.Size = new System.Drawing.Size(24, 17);
            this.popisekKčDPH.TabIndex = 7;
            this.popisekKčDPH.Text = "Kč";
            // 
            // poleCena
            // 
            this.poleCena.Location = new System.Drawing.Point(264, 47);
            this.poleCena.Name = "poleCena";
            this.poleCena.Size = new System.Drawing.Size(134, 22);
            this.poleCena.TabIndex = 8;
            this.poleCena.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // poleSazbaDPH
            // 
            this.poleSazbaDPH.Location = new System.Drawing.Point(264, 112);
            this.poleSazbaDPH.Name = "poleSazbaDPH";
            this.poleSazbaDPH.Size = new System.Drawing.Size(134, 22);
            this.poleSazbaDPH.TabIndex = 9;
            this.poleSazbaDPH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tlačítkoVypočti
            // 
            this.tlačítkoVypočti.Location = new System.Drawing.Point(200, 162);
            this.tlačítkoVypočti.Name = "tlačítkoVypočti";
            this.tlačítkoVypočti.Size = new System.Drawing.Size(121, 38);
            this.tlačítkoVypočti.TabIndex = 10;
            this.tlačítkoVypočti.Text = "&Vypočti";
            this.tlačítkoVypočti.UseVisualStyleBackColor = true;
            this.tlačítkoVypočti.Click += new System.EventHandler(this.tlačítkoVypočti_Click);
            // 
            // poleBezDPH
            // 
            this.poleBezDPH.Enabled = false;
            this.poleBezDPH.Location = new System.Drawing.Point(264, 224);
            this.poleBezDPH.Name = "poleBezDPH";
            this.poleBezDPH.Size = new System.Drawing.Size(134, 22);
            this.poleBezDPH.TabIndex = 11;
            this.poleBezDPH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // poleDPH
            // 
            this.poleDPH.Enabled = false;
            this.poleDPH.Location = new System.Drawing.Point(264, 276);
            this.poleDPH.Name = "poleDPH";
            this.poleDPH.Size = new System.Drawing.Size(134, 22);
            this.poleDPH.TabIndex = 12;
            this.poleDPH.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // oknoDPH
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(538, 383);
            this.Controls.Add(this.poleDPH);
            this.Controls.Add(this.poleBezDPH);
            this.Controls.Add(this.tlačítkoVypočti);
            this.Controls.Add(this.poleSazbaDPH);
            this.Controls.Add(this.poleCena);
            this.Controls.Add(this.popisekKčDPH);
            this.Controls.Add(this.popisekKčBezDPH);
            this.Controls.Add(this.popisekProcenta);
            this.Controls.Add(this.popisekKčSDPH);
            this.Controls.Add(this.popisekDPH);
            this.Controls.Add(this.popisekCenaBezDPH);
            this.Controls.Add(this.popisekSazbaDPH);
            this.Controls.Add(this.popisekCenaSDPH);
            this.Name = "oknoDPH";
            this.Text = "DPH";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekCenaSDPH;
        private System.Windows.Forms.Label popisekSazbaDPH;
        private System.Windows.Forms.Label popisekCenaBezDPH;
        private System.Windows.Forms.Label popisekDPH;
        private System.Windows.Forms.Label popisekKčSDPH;
        private System.Windows.Forms.Label popisekProcenta;
        private System.Windows.Forms.Label popisekKčBezDPH;
        private System.Windows.Forms.Label popisekKčDPH;
        private System.Windows.Forms.TextBox poleCena;
        private System.Windows.Forms.TextBox poleSazbaDPH;
        private System.Windows.Forms.Button tlačítkoVypočti;
        private System.Windows.Forms.TextBox poleBezDPH;
        private System.Windows.Forms.TextBox poleDPH;
    }
}

