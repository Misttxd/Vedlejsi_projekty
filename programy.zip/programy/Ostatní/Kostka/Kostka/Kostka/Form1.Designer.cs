﻿namespace Kostka
{
    partial class oknoKostka
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlačítkoHoď = new System.Windows.Forms.Button();
            this.poleČíslo = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // tlačítkoHoď
            // 
            this.tlačítkoHoď.Location = new System.Drawing.Point(148, 296);
            this.tlačítkoHoď.Name = "tlačítkoHoď";
            this.tlačítkoHoď.Size = new System.Drawing.Size(126, 57);
            this.tlačítkoHoď.TabIndex = 0;
            this.tlačítkoHoď.Text = "&Hoď";
            this.tlačítkoHoď.UseVisualStyleBackColor = true;
            this.tlačítkoHoď.Click += new System.EventHandler(this.tlačítkoHoď_Click);
            // 
            // poleČíslo
            // 
            this.poleČíslo.Font = new System.Drawing.Font("Microsoft Sans Serif", 100.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.poleČíslo.Location = new System.Drawing.Point(60, 34);
            this.poleČíslo.Multiline = true;
            this.poleČíslo.Name = "poleČíslo";
            this.poleČíslo.ReadOnly = true;
            this.poleČíslo.Size = new System.Drawing.Size(322, 231);
            this.poleČíslo.TabIndex = 1;
            this.poleČíslo.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // oknoKostka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(443, 382);
            this.Controls.Add(this.poleČíslo);
            this.Controls.Add(this.tlačítkoHoď);
            this.Name = "oknoKostka";
            this.Text = "Kostka";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tlačítkoHoď;
        private System.Windows.Forms.TextBox poleČíslo;
    }
}

