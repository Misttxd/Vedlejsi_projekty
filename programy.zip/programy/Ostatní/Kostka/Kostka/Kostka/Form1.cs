﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Kostka
{
    public partial class oknoKostka : Form
    {
        Random náhoda = new Random();

        public oknoKostka()
        {
            InitializeComponent();
        }

        private void tlačítkoHoď_Click(object sender, EventArgs e)
        {
            int číslo = náhoda.Next(1, 6 + 1);
            poleČíslo.Text = číslo.ToString();
        }

    }
}
