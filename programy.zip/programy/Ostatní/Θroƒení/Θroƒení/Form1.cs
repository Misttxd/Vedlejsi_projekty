﻿using System;
using System.Windows.Forms;

namespace Úročení
{
    public partial class oknoProgramu : Form
    {
        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void tlačítkoSpočti_Click(object sender, EventArgs e)
        {
            try
            {
                // Převody do číselné formy
                double v = Convert.ToDouble(poleVklad.Text);
                double p = Convert.ToDouble(poleSazba.Text);
                double n = Convert.ToDouble(polePočetLet.Text);

                // Výpočet
                double základ = 1 + p/100.0;
                double výslednáČástka = v * Math.Pow(základ, n);

                // Zobrazení výsledku
                poleVýslednáČástka.Text = výslednáČástka.ToString("N2");
            }
            catch 
            {
                poleVýslednáČástka.Text = null;
            }
        }
    }
}