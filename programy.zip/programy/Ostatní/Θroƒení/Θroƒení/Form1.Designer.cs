﻿namespace Úročení
{
    partial class oknoProgramu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekVklad = new System.Windows.Forms.Label();
            this.poleVklad = new System.Windows.Forms.TextBox();
            this.popisekSazba = new System.Windows.Forms.Label();
            this.poleSazba = new System.Windows.Forms.TextBox();
            this.popisekPočetLet = new System.Windows.Forms.Label();
            this.polePočetLet = new System.Windows.Forms.TextBox();
            this.tlačítkoSpočti = new System.Windows.Forms.Button();
            this.popisekVýslednáČástka = new System.Windows.Forms.Label();
            this.poleVýslednáČástka = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // popisekVklad
            // 
            this.popisekVklad.AutoSize = true;
            this.popisekVklad.Location = new System.Drawing.Point(12, 15);
            this.popisekVklad.Name = "popisekVklad";
            this.popisekVklad.Size = new System.Drawing.Size(53, 13);
            this.popisekVklad.TabIndex = 0;
            this.popisekVklad.Text = "&Vklad Kč:";
            // 
            // poleVklad
            // 
            this.poleVklad.Location = new System.Drawing.Point(122, 12);
            this.poleVklad.Name = "poleVklad";
            this.poleVklad.Size = new System.Drawing.Size(95, 20);
            this.poleVklad.TabIndex = 1;
            this.poleVklad.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // popisekSazba
            // 
            this.popisekSazba.AutoSize = true;
            this.popisekSazba.Location = new System.Drawing.Point(12, 41);
            this.popisekSazba.Name = "popisekSazba";
            this.popisekSazba.Size = new System.Drawing.Size(93, 13);
            this.popisekSazba.TabIndex = 2;
            this.popisekSazba.Text = "&Úroková sazba %:";
            // 
            // poleSazba
            // 
            this.poleSazba.Location = new System.Drawing.Point(122, 38);
            this.poleSazba.Name = "poleSazba";
            this.poleSazba.Size = new System.Drawing.Size(95, 20);
            this.poleSazba.TabIndex = 3;
            this.poleSazba.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // popisekPočetLet
            // 
            this.popisekPočetLet.AutoSize = true;
            this.popisekPočetLet.Location = new System.Drawing.Point(12, 67);
            this.popisekPočetLet.Name = "popisekPočetLet";
            this.popisekPočetLet.Size = new System.Drawing.Size(52, 13);
            this.popisekPočetLet.TabIndex = 4;
            this.popisekPočetLet.Text = "&Počet let:";
            // 
            // polePočetLet
            // 
            this.polePočetLet.Location = new System.Drawing.Point(122, 64);
            this.polePočetLet.Name = "polePočetLet";
            this.polePočetLet.Size = new System.Drawing.Size(95, 20);
            this.polePočetLet.TabIndex = 5;
            this.polePočetLet.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tlačítkoSpočti
            // 
            this.tlačítkoSpočti.Location = new System.Drawing.Point(67, 99);
            this.tlačítkoSpočti.Name = "tlačítkoSpočti";
            this.tlačítkoSpočti.Size = new System.Drawing.Size(94, 23);
            this.tlačítkoSpočti.TabIndex = 6;
            this.tlačítkoSpočti.Text = "&Spočti";
            this.tlačítkoSpočti.UseVisualStyleBackColor = true;
            this.tlačítkoSpočti.Click += new System.EventHandler(this.tlačítkoSpočti_Click);
            // 
            // popisekVýslednáČástka
            // 
            this.popisekVýslednáČástka.AutoSize = true;
            this.popisekVýslednáČástka.Location = new System.Drawing.Point(12, 140);
            this.popisekVýslednáČástka.Name = "popisekVýslednáČástka";
            this.popisekVýslednáČástka.Size = new System.Drawing.Size(104, 13);
            this.popisekVýslednáČástka.TabIndex = 7;
            this.popisekVýslednáČástka.Text = "V&ýsledná částka Kč:";
            // 
            // poleVýslednáČástka
            // 
            this.poleVýslednáČástka.Location = new System.Drawing.Point(122, 137);
            this.poleVýslednáČástka.Name = "poleVýslednáČástka";
            this.poleVýslednáČástka.ReadOnly = true;
            this.poleVýslednáČástka.Size = new System.Drawing.Size(95, 20);
            this.poleVýslednáČástka.TabIndex = 8;
            this.poleVýslednáČástka.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // oknoProgramu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(228, 169);
            this.Controls.Add(this.tlačítkoSpočti);
            this.Controls.Add(this.poleVýslednáČástka);
            this.Controls.Add(this.popisekVýslednáČástka);
            this.Controls.Add(this.polePočetLet);
            this.Controls.Add(this.popisekPočetLet);
            this.Controls.Add(this.poleSazba);
            this.Controls.Add(this.popisekSazba);
            this.Controls.Add(this.poleVklad);
            this.Controls.Add(this.popisekVklad);
            this.MaximizeBox = false;
            this.Name = "oknoProgramu";
            this.Text = "Úročení";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekVklad;
        private System.Windows.Forms.TextBox poleVklad;
        private System.Windows.Forms.Label popisekSazba;
        private System.Windows.Forms.TextBox poleSazba;
        private System.Windows.Forms.Label popisekPočetLet;
        private System.Windows.Forms.TextBox polePočetLet;
        private System.Windows.Forms.Button tlačítkoSpočti;
        private System.Windows.Forms.Label popisekVýslednáČástka;
        private System.Windows.Forms.TextBox poleVýslednáČástka;
    }
}

