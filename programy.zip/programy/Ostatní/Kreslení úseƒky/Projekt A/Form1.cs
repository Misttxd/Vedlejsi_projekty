﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Projekt_A
{
    public partial class oknoKresleníÚsečky : Form
    {
        public oknoKresleníÚsečky()
        {
            InitializeComponent();
        }

        private void panel_Paint(object sender, PaintEventArgs e)
        {
            Graphics kreslícíPlocha = e.Graphics;
            //šířka a výška panelu
            int šířka = panel.ClientSize.Width;
            int výška = panel.ClientSize.Height;
            //ohraničení panelu
            kreslícíPlocha.DrawLine(Pens.Black, 0, 0, 0, výška);
            kreslícíPlocha.DrawLine(Pens.Black, 0, 0, šířka, 0);
            kreslícíPlocha.DrawLine(Pens.Black, šířka-1, 0, šířka-1, výška);
            kreslícíPlocha.DrawLine(Pens.Black, 0, výška-1, šířka, výška-1);

            try
            {
                int X1, X2, Y1, Y2;
                X1 = Convert.ToInt32(poleX1.Text);
                X2 = Convert.ToInt32(poleX2.Text);
                Y1 = Convert.ToInt32(poleY1.Text);
                Y2 = Convert.ToInt32(poleY2.Text);

                kreslícíPlocha.DrawLine(Pens.Blue, X1, Y1, X2, Y2);
            }
            catch (Exception)
            {
                
            }
        }

        private void pole_TextChanged(object sender, EventArgs e)
        {
            panel.Refresh();
        }
    }
}
