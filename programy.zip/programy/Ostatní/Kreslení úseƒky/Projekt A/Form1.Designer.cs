﻿namespace Projekt_A
{
    partial class oknoKresleníÚsečky
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel = new System.Windows.Forms.Panel();
            this.poleX1 = new System.Windows.Forms.TextBox();
            this.poleY1 = new System.Windows.Forms.TextBox();
            this.poleX2 = new System.Windows.Forms.TextBox();
            this.poleY2 = new System.Windows.Forms.TextBox();
            this.popisekPrvníBod = new System.Windows.Forms.Label();
            this.popisekDruhýBod = new System.Windows.Forms.Label();
            this.popisekX1 = new System.Windows.Forms.Label();
            this.popisekY1 = new System.Windows.Forms.Label();
            this.popisekX2 = new System.Windows.Forms.Label();
            this.popisekY2 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // panel
            // 
            this.panel.Location = new System.Drawing.Point(326, 64);
            this.panel.Name = "panel";
            this.panel.Size = new System.Drawing.Size(432, 372);
            this.panel.TabIndex = 0;
            this.panel.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_Paint);
            // 
            // poleX1
            // 
            this.poleX1.Location = new System.Drawing.Point(86, 108);
            this.poleX1.Name = "poleX1";
            this.poleX1.Size = new System.Drawing.Size(134, 22);
            this.poleX1.TabIndex = 1;
            this.poleX1.TextChanged += new System.EventHandler(this.pole_TextChanged);
            // 
            // poleY1
            // 
            this.poleY1.Location = new System.Drawing.Point(86, 147);
            this.poleY1.Name = "poleY1";
            this.poleY1.Size = new System.Drawing.Size(134, 22);
            this.poleY1.TabIndex = 2;
            this.poleY1.TextChanged += new System.EventHandler(this.pole_TextChanged);
            // 
            // poleX2
            // 
            this.poleX2.Location = new System.Drawing.Point(86, 253);
            this.poleX2.Name = "poleX2";
            this.poleX2.Size = new System.Drawing.Size(134, 22);
            this.poleX2.TabIndex = 3;
            this.poleX2.TextChanged += new System.EventHandler(this.pole_TextChanged);
            // 
            // poleY2
            // 
            this.poleY2.Location = new System.Drawing.Point(86, 295);
            this.poleY2.Name = "poleY2";
            this.poleY2.Size = new System.Drawing.Size(134, 22);
            this.poleY2.TabIndex = 4;
            this.poleY2.TextChanged += new System.EventHandler(this.pole_TextChanged);
            // 
            // popisekPrvníBod
            // 
            this.popisekPrvníBod.AutoSize = true;
            this.popisekPrvníBod.Location = new System.Drawing.Point(83, 64);
            this.popisekPrvníBod.Name = "popisekPrvníBod";
            this.popisekPrvníBod.Size = new System.Drawing.Size(68, 17);
            this.popisekPrvníBod.TabIndex = 5;
            this.popisekPrvníBod.Text = "První bod";
            // 
            // popisekDruhýBod
            // 
            this.popisekDruhýBod.AutoSize = true;
            this.popisekDruhýBod.Location = new System.Drawing.Point(83, 206);
            this.popisekDruhýBod.Name = "popisekDruhýBod";
            this.popisekDruhýBod.Size = new System.Drawing.Size(74, 17);
            this.popisekDruhýBod.TabIndex = 6;
            this.popisekDruhýBod.Text = "Druhý bod";
            // 
            // popisekX1
            // 
            this.popisekX1.AutoSize = true;
            this.popisekX1.Location = new System.Drawing.Point(23, 113);
            this.popisekX1.Name = "popisekX1";
            this.popisekX1.Size = new System.Drawing.Size(21, 17);
            this.popisekX1.TabIndex = 7;
            this.popisekX1.Text = "X:";
            // 
            // popisekY1
            // 
            this.popisekY1.AutoSize = true;
            this.popisekY1.Location = new System.Drawing.Point(23, 152);
            this.popisekY1.Name = "popisekY1";
            this.popisekY1.Size = new System.Drawing.Size(21, 17);
            this.popisekY1.TabIndex = 8;
            this.popisekY1.Text = "Y:";
            // 
            // popisekX2
            // 
            this.popisekX2.AutoSize = true;
            this.popisekX2.Location = new System.Drawing.Point(23, 258);
            this.popisekX2.Name = "popisekX2";
            this.popisekX2.Size = new System.Drawing.Size(21, 17);
            this.popisekX2.TabIndex = 9;
            this.popisekX2.Text = "X:";
            // 
            // popisekY2
            // 
            this.popisekY2.AutoSize = true;
            this.popisekY2.Location = new System.Drawing.Point(23, 300);
            this.popisekY2.Name = "popisekY2";
            this.popisekY2.Size = new System.Drawing.Size(21, 17);
            this.popisekY2.TabIndex = 10;
            this.popisekY2.Text = "Y:";
            // 
            // oknoKresleníÚsečky
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(793, 483);
            this.Controls.Add(this.popisekY2);
            this.Controls.Add(this.popisekX2);
            this.Controls.Add(this.popisekY1);
            this.Controls.Add(this.popisekX1);
            this.Controls.Add(this.popisekDruhýBod);
            this.Controls.Add(this.popisekPrvníBod);
            this.Controls.Add(this.poleY2);
            this.Controls.Add(this.poleX2);
            this.Controls.Add(this.poleY1);
            this.Controls.Add(this.poleX1);
            this.Controls.Add(this.panel);
            this.Name = "oknoKresleníÚsečky";
            this.Text = "Kreslení úsečky";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel panel;
        private System.Windows.Forms.TextBox poleX1;
        private System.Windows.Forms.TextBox poleY1;
        private System.Windows.Forms.TextBox poleX2;
        private System.Windows.Forms.TextBox poleY2;
        private System.Windows.Forms.Label popisekPrvníBod;
        private System.Windows.Forms.Label popisekDruhýBod;
        private System.Windows.Forms.Label popisekX1;
        private System.Windows.Forms.Label popisekY1;
        private System.Windows.Forms.Label popisekX2;
        private System.Windows.Forms.Label popisekY2;
    }
}

