﻿using System;
using System.Windows.Forms;

namespace Meziroční_růst
{
    public partial class oknoProgramu : Form
    {
        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void tlačítkoVypočti_Click(object sender, EventArgs e)
        {
            // Převeď vstupní údaje na čísla
            double obratVýchozí = Convert.ToDouble(poleObratVýchozí.Text);
            double obratNásledující = Convert.ToDouble(poleObratNásledující.Text);

            // Proveď výpočet
            double růst = (obratNásledující - obratVýchozí) / obratVýchozí;
            double růstVProcentech = růst * 100;

            // Zobraz výsledek
            poleVýsledek.Text = 
                "Vzrůst obratu od roku " + poleRokVýchozí.Text + 
                " do roku " + poleRokNásledující.Text +
                " byl " + růstVProcentech.ToString("F1") +
                "% obratu roku " + poleRokVýchozí.Text;
        }

        private void poleRokVýchozí_TextChanged(object sender, EventArgs e)
        {
            try
            {
                int rokVýchozí = Convert.ToInt32(poleRokVýchozí.Text);
                int rokNásledující = rokVýchozí + 1;
                poleRokNásledující.Text = rokNásledující.ToString();
            }
            catch
            {
                poleRokNásledující.Text = null;
            }
        }
    }
}