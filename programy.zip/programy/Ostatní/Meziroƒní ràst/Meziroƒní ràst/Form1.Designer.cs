﻿namespace Meziroční_růst
{
    partial class oknoProgramu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekRokVýchozí = new System.Windows.Forms.Label();
            this.poleRokVýchozí = new System.Windows.Forms.TextBox();
            this.popisekObratVýchozí = new System.Windows.Forms.Label();
            this.poleObratVýchozí = new System.Windows.Forms.TextBox();
            this.popisekRokNásledující = new System.Windows.Forms.Label();
            this.popisekObratNásledující = new System.Windows.Forms.Label();
            this.poleObratNásledující = new System.Windows.Forms.TextBox();
            this.tlačítkoVypočti = new System.Windows.Forms.Button();
            this.poleVýsledek = new System.Windows.Forms.TextBox();
            this.poleRokNásledující = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // popisekRokVýchozí
            // 
            this.popisekRokVýchozí.AutoSize = true;
            this.popisekRokVýchozí.Location = new System.Drawing.Point(9, 23);
            this.popisekRokVýchozí.Name = "popisekRokVýchozí";
            this.popisekRokVýchozí.Size = new System.Drawing.Size(64, 13);
            this.popisekRokVýchozí.TabIndex = 0;
            this.popisekRokVýchozí.Text = "Výchozí rok";
            // 
            // poleRokVýchozí
            // 
            this.poleRokVýchozí.Location = new System.Drawing.Point(95, 20);
            this.poleRokVýchozí.Name = "poleRokVýchozí";
            this.poleRokVýchozí.Size = new System.Drawing.Size(41, 20);
            this.poleRokVýchozí.TabIndex = 1;
            this.poleRokVýchozí.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            this.poleRokVýchozí.TextChanged += new System.EventHandler(this.poleRokVýchozí_TextChanged);
            // 
            // popisekObratVýchozí
            // 
            this.popisekObratVýchozí.AutoSize = true;
            this.popisekObratVýchozí.Location = new System.Drawing.Point(148, 23);
            this.popisekObratVýchozí.Name = "popisekObratVýchozí";
            this.popisekObratVýchozí.Size = new System.Drawing.Size(71, 13);
            this.popisekObratVýchozí.TabIndex = 2;
            this.popisekObratVýchozí.Text = "Obrat (tis. Kč)";
            // 
            // poleObratVýchozí
            // 
            this.poleObratVýchozí.Location = new System.Drawing.Point(225, 20);
            this.poleObratVýchozí.Name = "poleObratVýchozí";
            this.poleObratVýchozí.Size = new System.Drawing.Size(69, 20);
            this.poleObratVýchozí.TabIndex = 3;
            this.poleObratVýchozí.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // popisekRokNásledující
            // 
            this.popisekRokNásledující.AutoSize = true;
            this.popisekRokNásledující.Location = new System.Drawing.Point(9, 53);
            this.popisekRokNásledující.Name = "popisekRokNásledující";
            this.popisekRokNásledující.Size = new System.Drawing.Size(80, 13);
            this.popisekRokNásledující.TabIndex = 4;
            this.popisekRokNásledující.Text = "Následující rok";
            // 
            // popisekObratNásledující
            // 
            this.popisekObratNásledující.AutoSize = true;
            this.popisekObratNásledující.Location = new System.Drawing.Point(148, 53);
            this.popisekObratNásledující.Name = "popisekObratNásledující";
            this.popisekObratNásledující.Size = new System.Drawing.Size(71, 13);
            this.popisekObratNásledující.TabIndex = 6;
            this.popisekObratNásledující.Text = "Obrat (tis. Kč)";
            // 
            // poleObratNásledující
            // 
            this.poleObratNásledující.Location = new System.Drawing.Point(225, 50);
            this.poleObratNásledující.Name = "poleObratNásledující";
            this.poleObratNásledující.Size = new System.Drawing.Size(69, 20);
            this.poleObratNásledující.TabIndex = 7;
            this.poleObratNásledující.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tlačítkoVypočti
            // 
            this.tlačítkoVypočti.Location = new System.Drawing.Point(70, 85);
            this.tlačítkoVypočti.Name = "tlačítkoVypočti";
            this.tlačítkoVypočti.Size = new System.Drawing.Size(173, 23);
            this.tlačítkoVypočti.TabIndex = 8;
            this.tlačítkoVypočti.Text = "&Vypočti";
            this.tlačítkoVypočti.UseVisualStyleBackColor = true;
            this.tlačítkoVypočti.Click += new System.EventHandler(this.tlačítkoVypočti_Click);
            // 
            // poleVýsledek
            // 
            this.poleVýsledek.Location = new System.Drawing.Point(9, 123);
            this.poleVýsledek.Multiline = true;
            this.poleVýsledek.Name = "poleVýsledek";
            this.poleVýsledek.ReadOnly = true;
            this.poleVýsledek.Size = new System.Drawing.Size(285, 35);
            this.poleVýsledek.TabIndex = 9;
            // 
            // poleRokNásledující
            // 
            this.poleRokNásledující.Location = new System.Drawing.Point(95, 50);
            this.poleRokNásledující.Name = "poleRokNásledující";
            this.poleRokNásledující.ReadOnly = true;
            this.poleRokNásledující.Size = new System.Drawing.Size(41, 20);
            this.poleRokNásledující.TabIndex = 5;
            this.poleRokNásledující.TabStop = false;
            this.poleRokNásledující.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // oknoProgramu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(302, 178);
            this.Controls.Add(this.poleVýsledek);
            this.Controls.Add(this.tlačítkoVypočti);
            this.Controls.Add(this.poleObratNásledující);
            this.Controls.Add(this.poleObratVýchozí);
            this.Controls.Add(this.popisekObratNásledující);
            this.Controls.Add(this.popisekObratVýchozí);
            this.Controls.Add(this.poleRokNásledující);
            this.Controls.Add(this.poleRokVýchozí);
            this.Controls.Add(this.popisekRokNásledující);
            this.Controls.Add(this.popisekRokVýchozí);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "oknoProgramu";
            this.Text = "Meziroční růst";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekRokVýchozí;
        private System.Windows.Forms.TextBox poleRokVýchozí;
        private System.Windows.Forms.Label popisekObratVýchozí;
        private System.Windows.Forms.TextBox poleObratVýchozí;
        private System.Windows.Forms.Label popisekRokNásledující;
        private System.Windows.Forms.Label popisekObratNásledující;
        private System.Windows.Forms.TextBox poleObratNásledující;
        private System.Windows.Forms.Button tlačítkoVypočti;
        private System.Windows.Forms.TextBox poleVýsledek;
        private System.Windows.Forms.TextBox poleRokNásledující;
    }
}

