﻿namespace Výtah
{
    partial class oknoVýtah
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.poleVýtah = new System.Windows.Forms.TextBox();
            this.tlačítkoVýtah = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // poleVýtah
            // 
            this.poleVýtah.Location = new System.Drawing.Point(24, 24);
            this.poleVýtah.Multiline = true;
            this.poleVýtah.Name = "poleVýtah";
            this.poleVýtah.Size = new System.Drawing.Size(198, 174);
            this.poleVýtah.TabIndex = 0;
            // 
            // tlačítkoVýtah
            // 
            this.tlačítkoVýtah.Location = new System.Drawing.Point(24, 230);
            this.tlačítkoVýtah.Name = "tlačítkoVýtah";
            this.tlačítkoVýtah.Size = new System.Drawing.Size(198, 29);
            this.tlačítkoVýtah.TabIndex = 1;
            this.tlačítkoVýtah.Text = "Výtah";
            this.tlačítkoVýtah.UseVisualStyleBackColor = true;
            this.tlačítkoVýtah.Click += new System.EventHandler(this.tlačítkoVýtah_Click);
            // 
            // oknoVýtah
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(248, 292);
            this.Controls.Add(this.tlačítkoVýtah);
            this.Controls.Add(this.poleVýtah);
            this.Name = "oknoVýtah";
            this.Text = "Výtah";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox poleVýtah;
        private System.Windows.Forms.Button tlačítkoVýtah;
    }
}

