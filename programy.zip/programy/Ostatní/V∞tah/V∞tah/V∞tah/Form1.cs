﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Výtah
{
    public partial class oknoVýtah : Form
    {
        public oknoVýtah()
        {
            InitializeComponent();
        }

        Random Náhoda = new Random();

        private void tlačítkoVýtah_Click(object sender, EventArgs e)
        {
            poleVýtah.Text = null;
            int osoba = 0;
            int i = 0;
            int celkem = 0;
            int nosnost = 300;
            while (celkem <= nosnost)
            {
                osoba = Náhoda.Next(10, 101);
                celkem += osoba;
                
                if (celkem <= nosnost)
                {
                    i++;
                    poleVýtah.Text += i.ToString() + ". " + "hmotnost: " +
                   osoba.ToString() + Environment.NewLine;
                }
               
            }
                 celkem -= osoba;
                 poleVýtah.Text += "Nastoupilo " + i.ToString() + " osob" + Environment.NewLine + "o celkové hmotnosti "
                 + celkem.ToString() + " kg." + Environment.NewLine + " Osoba o váze " + osoba.ToString() + " se už nevešla.";
        }

    }
}
