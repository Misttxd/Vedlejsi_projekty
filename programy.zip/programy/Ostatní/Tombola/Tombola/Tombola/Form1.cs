﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Tombola
{
    public partial class oknoTombola : Form
    {
        public oknoTombola()
        {
            InitializeComponent();
        }

        string[] tombola = new string[20];
        private void button1_Click(object sender, EventArgs e)
        {
            int pocetPolozek = 0;
            for (int i = 0; i < tombola.Length; i++)
            {
                if (tombola[i] != null)
                {
                    pocetPolozek++;
                }
            }
            MessageBox.Show("Počet položek v tombole:" + pocetPolozek.ToString());
        }

        private void tlacitkoVloz_Click(object sender, EventArgs e)
        {
            try
            {
                string polozka = polePoložka.Text;
                int cisloPolozky = Convert.ToInt32(poleCislo.Text);

                tombola[cisloPolozky - 1] = polozka;
            }
            catch (Exception)
            {
                MessageBox.Show("Vstupní data nejsou zadána ve správném formátu");
            }
        }

        private void tlacitkoOdeber_Click(object sender, EventArgs e)
        {
            try
            {
                int cisloPolozky = Convert.ToInt32(poleCislo.Text);
                tombola[cisloPolozky - 1] = null;
            }
            catch (Exception)
            {

                MessageBox.Show("Vstupní data nejsou zadána ve správném formátu");
            }
        }

        private void tlačítkoZobraz_Click(object sender, EventArgs e)
        {
            string zprava = "";
            for (int i = 0; i<tombola.Length; i++)
            {
                if (tombola[i] != null)
                {
                    zprava += (i+1).ToString() + ". " + tombola[i] + Environment.NewLine;
                }
            }

            polePrehled.Text = zprava;
        }
    }
}
