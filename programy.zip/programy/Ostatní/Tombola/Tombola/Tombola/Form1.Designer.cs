﻿namespace Tombola
{
    partial class oknoTombola
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tlačítkoZobraz = new System.Windows.Forms.Button();
            this.polePrehled = new System.Windows.Forms.TextBox();
            this.tlacitkoVloz = new System.Windows.Forms.Button();
            this.poleCislo = new System.Windows.Forms.TextBox();
            this.polePoložka = new System.Windows.Forms.TextBox();
            this.popisekCislo = new System.Windows.Forms.Label();
            this.popisekJméno = new System.Windows.Forms.Label();
            this.tlacitkoOdeber = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // tlačítkoZobraz
            // 
            this.tlačítkoZobraz.Location = new System.Drawing.Point(391, 21);
            this.tlačítkoZobraz.Name = "tlačítkoZobraz";
            this.tlačítkoZobraz.Size = new System.Drawing.Size(130, 49);
            this.tlačítkoZobraz.TabIndex = 0;
            this.tlačítkoZobraz.Text = "Zobraz tombolu";
            this.tlačítkoZobraz.UseVisualStyleBackColor = true;
            this.tlačítkoZobraz.Click += new System.EventHandler(this.tlačítkoZobraz_Click);
            // 
            // polePrehled
            // 
            this.polePrehled.Location = new System.Drawing.Point(375, 102);
            this.polePrehled.Multiline = true;
            this.polePrehled.Name = "polePrehled";
            this.polePrehled.Size = new System.Drawing.Size(177, 242);
            this.polePrehled.TabIndex = 1;
            // 
            // tlacitkoVloz
            // 
            this.tlacitkoVloz.Location = new System.Drawing.Point(25, 25);
            this.tlacitkoVloz.Name = "tlacitkoVloz";
            this.tlacitkoVloz.Size = new System.Drawing.Size(144, 41);
            this.tlacitkoVloz.TabIndex = 2;
            this.tlacitkoVloz.Text = "Vlož položku";
            this.tlacitkoVloz.UseVisualStyleBackColor = true;
            this.tlacitkoVloz.Click += new System.EventHandler(this.tlacitkoVloz_Click);
            // 
            // poleCislo
            // 
            this.poleCislo.Location = new System.Drawing.Point(33, 102);
            this.poleCislo.Name = "poleCislo";
            this.poleCislo.Size = new System.Drawing.Size(100, 22);
            this.poleCislo.TabIndex = 3;
            // 
            // polePoložka
            // 
            this.polePoložka.Location = new System.Drawing.Point(195, 102);
            this.polePoložka.Name = "polePoložka";
            this.polePoložka.Size = new System.Drawing.Size(100, 22);
            this.polePoložka.TabIndex = 4;
            // 
            // popisekCislo
            // 
            this.popisekCislo.AutoSize = true;
            this.popisekCislo.Location = new System.Drawing.Point(33, 84);
            this.popisekCislo.Name = "popisekCislo";
            this.popisekCislo.Size = new System.Drawing.Size(90, 16);
            this.popisekCislo.TabIndex = 5;
            this.popisekCislo.Text = "Číslo položky:";
            // 
            // popisekJméno
            // 
            this.popisekJméno.AutoSize = true;
            this.popisekJméno.Location = new System.Drawing.Point(192, 84);
            this.popisekJméno.Name = "popisekJméno";
            this.popisekJméno.Size = new System.Drawing.Size(101, 16);
            this.popisekJméno.TabIndex = 6;
            this.popisekJméno.Text = "Jméno položky:";
            // 
            // tlacitkoOdeber
            // 
            this.tlacitkoOdeber.Location = new System.Drawing.Point(195, 25);
            this.tlacitkoOdeber.Name = "tlacitkoOdeber";
            this.tlacitkoOdeber.Size = new System.Drawing.Size(150, 41);
            this.tlacitkoOdeber.TabIndex = 7;
            this.tlacitkoOdeber.Text = "Odeber položku";
            this.tlacitkoOdeber.UseVisualStyleBackColor = true;
            this.tlacitkoOdeber.Click += new System.EventHandler(this.tlacitkoOdeber_Click);
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(34, 175);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(163, 53);
            this.button1.TabIndex = 8;
            this.button1.Text = "Zobraz počet položek";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // oknoTombola
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(607, 381);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.tlacitkoOdeber);
            this.Controls.Add(this.popisekJméno);
            this.Controls.Add(this.popisekCislo);
            this.Controls.Add(this.polePoložka);
            this.Controls.Add(this.poleCislo);
            this.Controls.Add(this.tlacitkoVloz);
            this.Controls.Add(this.polePrehled);
            this.Controls.Add(this.tlačítkoZobraz);
            this.Name = "oknoTombola";
            this.Text = "Evidence tomboly";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button tlačítkoZobraz;
        private System.Windows.Forms.TextBox polePrehled;
        private System.Windows.Forms.Button tlacitkoVloz;
        private System.Windows.Forms.TextBox poleCislo;
        private System.Windows.Forms.TextBox polePoložka;
        private System.Windows.Forms.Label popisekCislo;
        private System.Windows.Forms.Label popisekJméno;
        private System.Windows.Forms.Button tlacitkoOdeber;
        private System.Windows.Forms.Button button1;
    }
}

