﻿using System;
using System.Windows.Forms;

namespace Kontrola_kostky
{
    public partial class oknoProgramu : Form
    {
        Random náhoda = new Random();

        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void tlačítkoSpusťTest_Click(object sender, EventArgs e)
        {
            int[] kolikrát = new int[7];

            int početHodů = 600;
            for (int čísloHodu = 1; čísloHodu <= početHodů; čísloHodu++)
            {
                int hozenéČíslo = náhoda.Next(1, 6+1);
                kolikrát[hozenéČíslo]++;
            }

            string zpráva = null;
            for (int číslo = 1; číslo <= 6; číslo++)
            {
                zpráva += číslo.ToString() + ": " + 
                    kolikrát[číslo].ToString() + "x" +
                    Environment.NewLine;
            }
            poleVýsledky.Text = zpráva;
        }
    }
}
