﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pole_náhodných_čísel
{
    public partial class oknoPoleNáhodnýchĆísel : Form
    {
        public oknoPoleNáhodnýchĆísel()
        {
            InitializeComponent();
        }

        Random náhoda = new Random();
        int[] celá_čísla = new int[20];
        int[] četnost = new int[11];

        private void tlačítkoGeneruj_Click(object sender, EventArgs e)
        {
            int číslo;
            string zpráva="";
            for (int i = 0; i < celá_čísla.Length; i++)
            {
                číslo = náhoda.Next(1, 10 + 1);
                celá_čísla[i] = číslo;
                četnost[číslo]++;
                zpráva += celá_čísla[i].ToString() + Environment.NewLine; 
            }
            poleText.Text = zpráva;
        }

        private void tlačítkoČetnost_Click(object sender, EventArgs e)
        {
            string zpráva = "";
            for (int i = 1; i < četnost.Length; i++)
            {
                zpráva +=i.ToString() +":"+ četnost[i].ToString() + " x" + Environment.NewLine;
            }
            poleČetnost.Text = zpráva;
        }
    }
}
