﻿namespace Pole_náhodných_čísel
{
    partial class oknoPoleNáhodnýchĆísel
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.poleText = new System.Windows.Forms.TextBox();
            this.tlačítkoGeneruj = new System.Windows.Forms.Button();
            this.tlačítkoČetnost = new System.Windows.Forms.Button();
            this.poleČetnost = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // poleText
            // 
            this.poleText.Enabled = false;
            this.poleText.Location = new System.Drawing.Point(140, 12);
            this.poleText.Multiline = true;
            this.poleText.Name = "poleText";
            this.poleText.Size = new System.Drawing.Size(29, 282);
            this.poleText.TabIndex = 0;
            // 
            // tlačítkoGeneruj
            // 
            this.tlačítkoGeneruj.Location = new System.Drawing.Point(23, 23);
            this.tlačítkoGeneruj.Name = "tlačítkoGeneruj";
            this.tlačítkoGeneruj.Size = new System.Drawing.Size(97, 35);
            this.tlačítkoGeneruj.TabIndex = 1;
            this.tlačítkoGeneruj.Text = "Generuj";
            this.tlačítkoGeneruj.UseVisualStyleBackColor = true;
            this.tlačítkoGeneruj.Click += new System.EventHandler(this.tlačítkoGeneruj_Click);
            // 
            // tlačítkoČetnost
            // 
            this.tlačítkoČetnost.Location = new System.Drawing.Point(23, 79);
            this.tlačítkoČetnost.Name = "tlačítkoČetnost";
            this.tlačítkoČetnost.Size = new System.Drawing.Size(97, 39);
            this.tlačítkoČetnost.TabIndex = 2;
            this.tlačítkoČetnost.Text = "Četnost";
            this.tlačítkoČetnost.UseVisualStyleBackColor = true;
            this.tlačítkoČetnost.Click += new System.EventHandler(this.tlačítkoČetnost_Click);
            // 
            // poleČetnost
            // 
            this.poleČetnost.Enabled = false;
            this.poleČetnost.Location = new System.Drawing.Point(21, 135);
            this.poleČetnost.Multiline = true;
            this.poleČetnost.Name = "poleČetnost";
            this.poleČetnost.Size = new System.Drawing.Size(99, 158);
            this.poleČetnost.TabIndex = 3;
            // 
            // oknoPoleNáhodnýchĆísel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(190, 306);
            this.Controls.Add(this.poleČetnost);
            this.Controls.Add(this.tlačítkoČetnost);
            this.Controls.Add(this.tlačítkoGeneruj);
            this.Controls.Add(this.poleText);
            this.Name = "oknoPoleNáhodnýchĆísel";
            this.Text = "Pole náhodných čísel";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox poleText;
        private System.Windows.Forms.Button tlačítkoGeneruj;
        private System.Windows.Forms.Button tlačítkoČetnost;
        private System.Windows.Forms.TextBox poleČetnost;
    }
}

