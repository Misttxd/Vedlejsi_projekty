﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Evidence_nájemníků
{
    public partial class oknoEvidenceNájemníků : Form
    {
        public oknoEvidenceNájemníků()
        {
            InitializeComponent();
        }

        string[] nájemníci = new string[13];

        private void oknoEvidenceNájemníků_Load(object sender, EventArgs e)
        {
            nájemníci[0] = "Palečkovi";
            nájemníci[1] = "Nováčkovi";
            nájemníci[4] = "Peterovi";
            nájemníci[5] = "Stehlíkovi";
            nájemníci[8] = "Cíchovi";
            nájemníci[11] = "Kutalovi";
        }

        private void tlačítkoNastěhovat_Click(object sender, EventArgs e)
        {
            int čísloBytu = Convert.ToInt32(poleČísloNastěhovat.Text);
            nájemníci[čísloBytu] = poleRodina.Text;
        }

        private void tlačítkoVystěhovat_Click(object sender, EventArgs e)
        {
            int čísloBytu = Convert.ToInt32(poleČísloVystěhovat.Text);
            nájemníci[čísloBytu] = null;
        }

        private void tlačítkoZobrazit_Click(object sender, EventArgs e)
        {
            int čísloBytu = Convert.ToInt32(poleČísloZobrazit.Text);
            MessageBox.Show("V tomto bytě bydlí: " + Convert.ToString(nájemníci[čísloBytu]));
        }

        private void tlačítkoZobrazitVšechny_Click(object sender, EventArgs e)
        {
            string zpráva = "";
            for (int čísloBytu = 0; čísloBytu < nájemníci.Length; čísloBytu++)
            {
                zpráva += čísloBytu.ToString() + ":" + nájemníci[čísloBytu] + Environment.NewLine;
            }
            MessageBox.Show(zpráva);
        }

    }
}
