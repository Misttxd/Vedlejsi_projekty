﻿namespace Evidence_nájemníků
{
    partial class oknoEvidenceNájemníků
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.poleRodina = new System.Windows.Forms.TextBox();
            this.poleČísloNastěhovat = new System.Windows.Forms.TextBox();
            this.poleČísloVystěhovat = new System.Windows.Forms.TextBox();
            this.poleČísloZobrazit = new System.Windows.Forms.TextBox();
            this.tlačítkoNastěhovat = new System.Windows.Forms.Button();
            this.tlačítkoVystěhovat = new System.Windows.Forms.Button();
            this.tlačítkoZobrazit = new System.Windows.Forms.Button();
            this.tlačítkoZobrazitVšechny = new System.Windows.Forms.Button();
            this.popisekRodina = new System.Windows.Forms.Label();
            this.popisekČísloBytuNastěhovat = new System.Windows.Forms.Label();
            this.popisekČísloBytuVystěhovat = new System.Windows.Forms.Label();
            this.popisekČísloBytuZobrazit = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // poleRodina
            // 
            this.poleRodina.Location = new System.Drawing.Point(132, 22);
            this.poleRodina.Name = "poleRodina";
            this.poleRodina.Size = new System.Drawing.Size(178, 20);
            this.poleRodina.TabIndex = 0;
            // 
            // poleČísloNastěhovat
            // 
            this.poleČísloNastěhovat.Location = new System.Drawing.Point(132, 69);
            this.poleČísloNastěhovat.Name = "poleČísloNastěhovat";
            this.poleČísloNastěhovat.Size = new System.Drawing.Size(54, 20);
            this.poleČísloNastěhovat.TabIndex = 1;
            // 
            // poleČísloVystěhovat
            // 
            this.poleČísloVystěhovat.Location = new System.Drawing.Point(132, 158);
            this.poleČísloVystěhovat.Name = "poleČísloVystěhovat";
            this.poleČísloVystěhovat.Size = new System.Drawing.Size(54, 20);
            this.poleČísloVystěhovat.TabIndex = 2;
            // 
            // poleČísloZobrazit
            // 
            this.poleČísloZobrazit.Location = new System.Drawing.Point(132, 255);
            this.poleČísloZobrazit.Name = "poleČísloZobrazit";
            this.poleČísloZobrazit.Size = new System.Drawing.Size(54, 20);
            this.poleČísloZobrazit.TabIndex = 3;
            // 
            // tlačítkoNastěhovat
            // 
            this.tlačítkoNastěhovat.Location = new System.Drawing.Point(215, 69);
            this.tlačítkoNastěhovat.Name = "tlačítkoNastěhovat";
            this.tlačítkoNastěhovat.Size = new System.Drawing.Size(95, 20);
            this.tlačítkoNastěhovat.TabIndex = 4;
            this.tlačítkoNastěhovat.Text = "&Nastěhovat";
            this.tlačítkoNastěhovat.UseVisualStyleBackColor = true;
            this.tlačítkoNastěhovat.Click += new System.EventHandler(this.tlačítkoNastěhovat_Click);
            // 
            // tlačítkoVystěhovat
            // 
            this.tlačítkoVystěhovat.Location = new System.Drawing.Point(215, 158);
            this.tlačítkoVystěhovat.Name = "tlačítkoVystěhovat";
            this.tlačítkoVystěhovat.Size = new System.Drawing.Size(95, 20);
            this.tlačítkoVystěhovat.TabIndex = 5;
            this.tlačítkoVystěhovat.Text = "&Vystěhovat";
            this.tlačítkoVystěhovat.UseVisualStyleBackColor = true;
            this.tlačítkoVystěhovat.Click += new System.EventHandler(this.tlačítkoVystěhovat_Click);
            // 
            // tlačítkoZobrazit
            // 
            this.tlačítkoZobrazit.Location = new System.Drawing.Point(215, 255);
            this.tlačítkoZobrazit.Name = "tlačítkoZobrazit";
            this.tlačítkoZobrazit.Size = new System.Drawing.Size(95, 20);
            this.tlačítkoZobrazit.TabIndex = 6;
            this.tlačítkoZobrazit.Text = "&Zobrazit";
            this.tlačítkoZobrazit.UseVisualStyleBackColor = true;
            this.tlačítkoZobrazit.Click += new System.EventHandler(this.tlačítkoZobrazit_Click);
            // 
            // tlačítkoZobrazitVšechny
            // 
            this.tlačítkoZobrazitVšechny.Location = new System.Drawing.Point(194, 321);
            this.tlačítkoZobrazitVšechny.Name = "tlačítkoZobrazitVšechny";
            this.tlačítkoZobrazitVšechny.Size = new System.Drawing.Size(116, 37);
            this.tlačítkoZobrazitVšechny.TabIndex = 7;
            this.tlačítkoZobrazitVšechny.Text = "Zobrazit všechny";
            this.tlačítkoZobrazitVšechny.UseVisualStyleBackColor = true;
            this.tlačítkoZobrazitVšechny.Click += new System.EventHandler(this.tlačítkoZobrazitVšechny_Click);
            // 
            // popisekRodina
            // 
            this.popisekRodina.AutoSize = true;
            this.popisekRodina.Location = new System.Drawing.Point(63, 29);
            this.popisekRodina.Name = "popisekRodina";
            this.popisekRodina.Size = new System.Drawing.Size(44, 13);
            this.popisekRodina.TabIndex = 8;
            this.popisekRodina.Text = "&Rodina:";
            // 
            // popisekČísloBytuNastěhovat
            // 
            this.popisekČísloBytuNastěhovat.AutoSize = true;
            this.popisekČísloBytuNastěhovat.Location = new System.Drawing.Point(63, 76);
            this.popisekČísloBytuNastěhovat.Name = "popisekČísloBytuNastěhovat";
            this.popisekČísloBytuNastěhovat.Size = new System.Drawing.Size(57, 13);
            this.popisekČísloBytuNastěhovat.TabIndex = 9;
            this.popisekČísloBytuNastěhovat.Text = "&Číslo bytu:";
            // 
            // popisekČísloBytuVystěhovat
            // 
            this.popisekČísloBytuVystěhovat.AutoSize = true;
            this.popisekČísloBytuVystěhovat.Location = new System.Drawing.Point(63, 165);
            this.popisekČísloBytuVystěhovat.Name = "popisekČísloBytuVystěhovat";
            this.popisekČísloBytuVystěhovat.Size = new System.Drawing.Size(57, 13);
            this.popisekČísloBytuVystěhovat.TabIndex = 10;
            this.popisekČísloBytuVystěhovat.Text = "Číslo &bytu:";
            // 
            // popisekČísloBytuZobrazit
            // 
            this.popisekČísloBytuZobrazit.AutoSize = true;
            this.popisekČísloBytuZobrazit.Location = new System.Drawing.Point(63, 262);
            this.popisekČísloBytuZobrazit.Name = "popisekČísloBytuZobrazit";
            this.popisekČísloBytuZobrazit.Size = new System.Drawing.Size(57, 13);
            this.popisekČísloBytuZobrazit.TabIndex = 11;
            this.popisekČísloBytuZobrazit.Text = "Číslo b&ytu:";
            // 
            // oknoEvidenceNájemníků
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(347, 392);
            this.Controls.Add(this.popisekČísloBytuZobrazit);
            this.Controls.Add(this.popisekČísloBytuVystěhovat);
            this.Controls.Add(this.popisekČísloBytuNastěhovat);
            this.Controls.Add(this.popisekRodina);
            this.Controls.Add(this.tlačítkoZobrazitVšechny);
            this.Controls.Add(this.tlačítkoZobrazit);
            this.Controls.Add(this.tlačítkoVystěhovat);
            this.Controls.Add(this.tlačítkoNastěhovat);
            this.Controls.Add(this.poleČísloZobrazit);
            this.Controls.Add(this.poleČísloVystěhovat);
            this.Controls.Add(this.poleČísloNastěhovat);
            this.Controls.Add(this.poleRodina);
            this.Name = "oknoEvidenceNájemníků";
            this.Text = "Evidence nájemníků";
            this.Load += new System.EventHandler(this.oknoEvidenceNájemníků_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox poleRodina;
        private System.Windows.Forms.TextBox poleČísloNastěhovat;
        private System.Windows.Forms.TextBox poleČísloVystěhovat;
        private System.Windows.Forms.TextBox poleČísloZobrazit;
        private System.Windows.Forms.Button tlačítkoNastěhovat;
        private System.Windows.Forms.Button tlačítkoVystěhovat;
        private System.Windows.Forms.Button tlačítkoZobrazit;
        private System.Windows.Forms.Button tlačítkoZobrazitVšechny;
        private System.Windows.Forms.Label popisekRodina;
        private System.Windows.Forms.Label popisekČísloBytuNastěhovat;
        private System.Windows.Forms.Label popisekČísloBytuVystěhovat;
        private System.Windows.Forms.Label popisekČísloBytuZobrazit;
    }
}

