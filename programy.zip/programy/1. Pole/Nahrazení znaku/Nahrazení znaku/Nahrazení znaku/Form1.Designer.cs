﻿namespace Nahrazení_znaku
{
    partial class oknoNahrazeníZnaku
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.poleVěta = new System.Windows.Forms.TextBox();
            this.popisekVěta = new System.Windows.Forms.Label();
            this.tlačítkoNahraď = new System.Windows.Forms.Button();
            this.popisekNováVěta = new System.Windows.Forms.Label();
            this.poleNováVěta = new System.Windows.Forms.TextBox();
            this.políčkoJinýZnak = new System.Windows.Forms.CheckBox();
            this.poleZnak = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // poleVěta
            // 
            this.poleVěta.Location = new System.Drawing.Point(85, 25);
            this.poleVěta.Name = "poleVěta";
            this.poleVěta.Size = new System.Drawing.Size(252, 20);
            this.poleVěta.TabIndex = 0;
            // 
            // popisekVěta
            // 
            this.popisekVěta.AutoSize = true;
            this.popisekVěta.Location = new System.Drawing.Point(19, 28);
            this.popisekVěta.Name = "popisekVěta";
            this.popisekVěta.Size = new System.Drawing.Size(32, 13);
            this.popisekVěta.TabIndex = 1;
            this.popisekVěta.Text = "Věta:";
            // 
            // tlačítkoNahraď
            // 
            this.tlačítkoNahraď.Location = new System.Drawing.Point(60, 114);
            this.tlačítkoNahraď.Name = "tlačítkoNahraď";
            this.tlačítkoNahraď.Size = new System.Drawing.Size(118, 33);
            this.tlačítkoNahraď.TabIndex = 2;
            this.tlačítkoNahraď.Text = "Nahraď znak a";
            this.tlačítkoNahraď.UseVisualStyleBackColor = true;
            this.tlačítkoNahraď.Click += new System.EventHandler(this.tlačítkoNahraď_Click);
            // 
            // popisekNováVěta
            // 
            this.popisekNováVěta.AutoSize = true;
            this.popisekNováVěta.Location = new System.Drawing.Point(19, 66);
            this.popisekNováVěta.Name = "popisekNováVěta";
            this.popisekNováVěta.Size = new System.Drawing.Size(60, 13);
            this.popisekNováVěta.TabIndex = 4;
            this.popisekNováVěta.Text = "Nová věta:";
            // 
            // poleNováVěta
            // 
            this.poleNováVěta.Enabled = false;
            this.poleNováVěta.Location = new System.Drawing.Point(85, 63);
            this.poleNováVěta.Name = "poleNováVěta";
            this.poleNováVěta.Size = new System.Drawing.Size(252, 20);
            this.poleNováVěta.TabIndex = 3;
            // 
            // políčkoJinýZnak
            // 
            this.políčkoJinýZnak.AutoSize = true;
            this.políčkoJinýZnak.Location = new System.Drawing.Point(225, 124);
            this.políčkoJinýZnak.Name = "políčkoJinýZnak";
            this.políčkoJinýZnak.Size = new System.Drawing.Size(70, 17);
            this.políčkoJinýZnak.TabIndex = 5;
            this.políčkoJinýZnak.Text = "Jiný znak";
            this.políčkoJinýZnak.UseVisualStyleBackColor = true;
            this.políčkoJinýZnak.CheckedChanged += new System.EventHandler(this.políčkoJinýZnak_CheckedChanged);
            // 
            // poleZnak
            // 
            this.poleZnak.Enabled = false;
            this.poleZnak.Location = new System.Drawing.Point(301, 121);
            this.poleZnak.MaxLength = 1;
            this.poleZnak.Name = "poleZnak";
            this.poleZnak.Size = new System.Drawing.Size(32, 20);
            this.poleZnak.TabIndex = 6;
            this.poleZnak.TextChanged += new System.EventHandler(this.poleZnak_TextChanged);
            // 
            // oknoNahrazeníZnaku
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(378, 193);
            this.Controls.Add(this.poleZnak);
            this.Controls.Add(this.políčkoJinýZnak);
            this.Controls.Add(this.popisekNováVěta);
            this.Controls.Add(this.poleNováVěta);
            this.Controls.Add(this.tlačítkoNahraď);
            this.Controls.Add(this.popisekVěta);
            this.Controls.Add(this.poleVěta);
            this.Name = "oknoNahrazeníZnaku";
            this.Text = "Nahrazení znaku";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox poleVěta;
        private System.Windows.Forms.Label popisekVěta;
        private System.Windows.Forms.Button tlačítkoNahraď;
        private System.Windows.Forms.Label popisekNováVěta;
        private System.Windows.Forms.TextBox poleNováVěta;
        private System.Windows.Forms.CheckBox políčkoJinýZnak;
        private System.Windows.Forms.TextBox poleZnak;
    }
}

