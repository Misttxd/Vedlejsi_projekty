﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nahrazení_znaku
{
    public partial class oknoNahrazeníZnaku : Form
    {
        public oknoNahrazeníZnaku()
        {
            InitializeComponent();
        }

        string znak = "a";

        private void tlačítkoNahraď_Click(object sender, EventArgs e)
        {
            string věta = poleVěta.Text;
            string nová_věta = null;
            for (int i = 0; i < věta.Length; i++)
            {
                if (věta[i] == znak[0])
                    nová_věta += "*";
                else
                    nová_věta += Convert.ToString(věta[i]);
            }
            poleNováVěta.Text = nová_věta;
        }

        private void políčkoJinýZnak_CheckedChanged(object sender, EventArgs e)
        {
            if (políčkoJinýZnak.Checked == true)
            {
                poleZnak.Enabled = true;
                tlačítkoNahraď.Text = "Nahraď znak " + poleZnak.Text;
                znak = poleZnak.Text;
            }
            else {
                poleZnak.Enabled = false;
                tlačítkoNahraď.Text = "Nahraď znak a";
                znak = "a";
            }
            
        }

        private void poleZnak_TextChanged(object sender, EventArgs e)
        {
            tlačítkoNahraď.Text = "Nahraď znak " + poleZnak.Text;
            znak = poleZnak.Text;
        }
    }
}
