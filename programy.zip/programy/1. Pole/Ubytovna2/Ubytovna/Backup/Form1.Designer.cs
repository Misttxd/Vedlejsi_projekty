﻿namespace Ubytovna
{
    partial class oknoProgramu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekPokoj = new System.Windows.Forms.Label();
            this.polePokoj = new System.Windows.Forms.TextBox();
            this.tlačítkoNastěhujHosta = new System.Windows.Forms.Button();
            this.tlačítkoVystěhujHosta = new System.Windows.Forms.Button();
            this.tlačítkoZobrazObsazení = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // popisekPokoj
            // 
            this.popisekPokoj.AutoSize = true;
            this.popisekPokoj.Location = new System.Drawing.Point(18, 39);
            this.popisekPokoj.Name = "popisekPokoj";
            this.popisekPokoj.Size = new System.Drawing.Size(37, 13);
            this.popisekPokoj.TabIndex = 0;
            this.popisekPokoj.Text = "&Pokoj:";
            // 
            // polePokoj
            // 
            this.polePokoj.Location = new System.Drawing.Point(61, 36);
            this.polePokoj.Name = "polePokoj";
            this.polePokoj.Size = new System.Drawing.Size(47, 20);
            this.polePokoj.TabIndex = 1;
            this.polePokoj.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // tlačítkoNastěhujHosta
            // 
            this.tlačítkoNastěhujHosta.Location = new System.Drawing.Point(123, 24);
            this.tlačítkoNastěhujHosta.Name = "tlačítkoNastěhujHosta";
            this.tlačítkoNastěhujHosta.Size = new System.Drawing.Size(96, 23);
            this.tlačítkoNastěhujHosta.TabIndex = 2;
            this.tlačítkoNastěhujHosta.Text = "&Nastěhuj hosta";
            this.tlačítkoNastěhujHosta.UseVisualStyleBackColor = true;
            this.tlačítkoNastěhujHosta.Click += new System.EventHandler(this.tlačítkoNastěhujHosta_Click);
            // 
            // tlačítkoVystěhujHosta
            // 
            this.tlačítkoVystěhujHosta.Location = new System.Drawing.Point(123, 53);
            this.tlačítkoVystěhujHosta.Name = "tlačítkoVystěhujHosta";
            this.tlačítkoVystěhujHosta.Size = new System.Drawing.Size(96, 23);
            this.tlačítkoVystěhujHosta.TabIndex = 3;
            this.tlačítkoVystěhujHosta.Text = "&Vystěhuj hosta";
            this.tlačítkoVystěhujHosta.UseVisualStyleBackColor = true;
            this.tlačítkoVystěhujHosta.Click += new System.EventHandler(this.tlačítkoVystěhujHosta_Click);
            // 
            // tlačítkoZobrazObsazení
            // 
            this.tlačítkoZobrazObsazení.Location = new System.Drawing.Point(21, 94);
            this.tlačítkoZobrazObsazení.Name = "tlačítkoZobrazObsazení";
            this.tlačítkoZobrazObsazení.Size = new System.Drawing.Size(198, 23);
            this.tlačítkoZobrazObsazení.TabIndex = 4;
            this.tlačítkoZobrazObsazení.Text = "&Zobraz obsazení pokojů";
            this.tlačítkoZobrazObsazení.UseVisualStyleBackColor = true;
            this.tlačítkoZobrazObsazení.Click += new System.EventHandler(this.tlačítkoZobrazObsazení_Click);
            // 
            // oknoProgramu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(236, 140);
            this.Controls.Add(this.tlačítkoZobrazObsazení);
            this.Controls.Add(this.tlačítkoVystěhujHosta);
            this.Controls.Add(this.tlačítkoNastěhujHosta);
            this.Controls.Add(this.polePokoj);
            this.Controls.Add(this.popisekPokoj);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.Name = "oknoProgramu";
            this.Text = "Ubytovna";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekPokoj;
        private System.Windows.Forms.TextBox polePokoj;
        private System.Windows.Forms.Button tlačítkoNastěhujHosta;
        private System.Windows.Forms.Button tlačítkoVystěhujHosta;
        private System.Windows.Forms.Button tlačítkoZobrazObsazení;
    }
}

