﻿using System;
using System.Windows.Forms;

namespace Ubytovna
{
    public partial class oknoProgramu : Form
    {
        int[] obsazeníPokojů = new int[10];
        int[] kapacityPokojů = new int[]{ 3, 3, 3, 3, 4, 4, 4, 6, 3, 8};

        public oknoProgramu()
        {
            InitializeComponent();
        }

        private void tlačítkoNastěhujHosta_Click(object sender, EventArgs e)
        {
            int pokoj = Convert.ToInt32(polePokoj.Text);
            if (obsazeníPokojů[pokoj] < kapacityPokojů[pokoj])
                obsazeníPokojů[pokoj]++;
            else
                MessageBox.Show("Pokoj " + polePokoj.Text + " je již obsazen!");
        }

        private void tlačítkoVystěhujHosta_Click(object sender, EventArgs e)
        {
            int pokoj = Convert.ToInt32(polePokoj.Text);
            if (obsazeníPokojů[pokoj] > 0)
                obsazeníPokojů[pokoj]--;
            else
                MessageBox.Show("Pokoj " + polePokoj.Text + " je již prázdný.");
        }

        private void tlačítkoZobrazObsazení_Click(object sender, EventArgs e)
        {
            string zpráva = null;
            for (int pokoj = 0; pokoj < obsazeníPokojů.Length; pokoj++)
                zpráva += "Pokoj č. " + pokoj.ToString() + ": " + 
                    obsazeníPokojů[pokoj] + "/" + kapacityPokojů[pokoj] + 
                    Environment.NewLine;
            MessageBox.Show(zpráva);
        }
    }
}
