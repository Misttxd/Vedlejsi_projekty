﻿namespace Počítání_znaků
{
    partial class oknoPočítání
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.popisekVěta = new System.Windows.Forms.Label();
            this.poleVěta = new System.Windows.Forms.TextBox();
            this.tlačítkoVypočítej = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // popisekVěta
            // 
            this.popisekVěta.AutoSize = true;
            this.popisekVěta.Location = new System.Drawing.Point(28, 33);
            this.popisekVěta.Name = "popisekVěta";
            this.popisekVěta.Size = new System.Drawing.Size(32, 13);
            this.popisekVěta.TabIndex = 0;
            this.popisekVěta.Text = "Věta:";
            // 
            // poleVěta
            // 
            this.poleVěta.Location = new System.Drawing.Point(66, 30);
            this.poleVěta.Name = "poleVěta";
            this.poleVěta.Size = new System.Drawing.Size(203, 20);
            this.poleVěta.TabIndex = 1;
            // 
            // tlačítkoVypočítej
            // 
            this.tlačítkoVypočítej.Location = new System.Drawing.Point(95, 76);
            this.tlačítkoVypočítej.Name = "tlačítkoVypočítej";
            this.tlačítkoVypočítej.Size = new System.Drawing.Size(104, 42);
            this.tlačítkoVypočítej.TabIndex = 2;
            this.tlačítkoVypočítej.Text = "Vypočítej";
            this.tlačítkoVypočítej.UseVisualStyleBackColor = true;
            this.tlačítkoVypočítej.Click += new System.EventHandler(this.tlačítkoVypočítej_Click);
            // 
            // oknoPočítání
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(308, 154);
            this.Controls.Add(this.tlačítkoVypočítej);
            this.Controls.Add(this.poleVěta);
            this.Controls.Add(this.popisekVěta);
            this.Name = "oknoPočítání";
            this.Text = "Počítání áček";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label popisekVěta;
        private System.Windows.Forms.TextBox poleVěta;
        private System.Windows.Forms.Button tlačítkoVypočítej;
    }
}

