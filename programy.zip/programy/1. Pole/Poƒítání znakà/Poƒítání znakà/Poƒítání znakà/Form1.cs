﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Počítání_znaků
{
    public partial class oknoPočítání : Form
    {
        public oknoPočítání()
        {
            InitializeComponent();
        }

        


        private void tlačítkoVypočítej_Click(object sender, EventArgs e)
        {
            int počet_áček = 0;
            string věta = poleVěta.Text;
            int počet_znaků = věta.Length;
            for (int číslo_znaku = 0; číslo_znaku < počet_znaků; číslo_znaku++)
            {
                if (věta[číslo_znaku] == 'a')
                {
                    počet_áček++;
                }
            }
            MessageBox.Show("Ve větě je: " + počet_áček.ToString() + " malých znaků a");

        }
    }
}
