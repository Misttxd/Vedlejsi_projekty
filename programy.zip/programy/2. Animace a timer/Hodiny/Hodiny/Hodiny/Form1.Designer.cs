﻿namespace Hodiny
{
    partial class OknoHodiny
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.poleHodiny = new System.Windows.Forms.TextBox();
            this.tlačítkoNastav = new System.Windows.Forms.Button();
            this.poleMinuty = new System.Windows.Forms.TextBox();
            this.poleSekundy = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // poleHodiny
            // 
            this.poleHodiny.Enabled = false;
            this.poleHodiny.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.poleHodiny.Location = new System.Drawing.Point(43, 55);
            this.poleHodiny.Name = "poleHodiny";
            this.poleHodiny.Size = new System.Drawing.Size(118, 47);
            this.poleHodiny.TabIndex = 0;
            this.poleHodiny.Text = "0";
            this.poleHodiny.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // tlačítkoNastav
            // 
            this.tlačítkoNastav.Font = new System.Drawing.Font("Microsoft Sans Serif", 36F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.tlačítkoNastav.Location = new System.Drawing.Point(511, 33);
            this.tlačítkoNastav.Name = "tlačítkoNastav";
            this.tlačítkoNastav.Size = new System.Drawing.Size(252, 81);
            this.tlačítkoNastav.TabIndex = 1;
            this.tlačítkoNastav.Text = "Nastav";
            this.tlačítkoNastav.UseVisualStyleBackColor = true;
            this.tlačítkoNastav.Click += new System.EventHandler(this.tlačítkoNastav_Click);
            // 
            // poleMinuty
            // 
            this.poleMinuty.Enabled = false;
            this.poleMinuty.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.poleMinuty.Location = new System.Drawing.Point(200, 55);
            this.poleMinuty.Name = "poleMinuty";
            this.poleMinuty.Size = new System.Drawing.Size(118, 47);
            this.poleMinuty.TabIndex = 2;
            this.poleMinuty.Text = "0";
            this.poleMinuty.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // poleSekundy
            // 
            this.poleSekundy.Enabled = false;
            this.poleSekundy.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.poleSekundy.Location = new System.Drawing.Point(358, 55);
            this.poleSekundy.Name = "poleSekundy";
            this.poleSekundy.Size = new System.Drawing.Size(118, 47);
            this.poleSekundy.TabIndex = 3;
            this.poleSekundy.Text = "0";
            this.poleSekundy.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label1.Location = new System.Drawing.Point(167, 55);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(28, 39);
            this.label1.TabIndex = 4;
            this.label1.Text = ":";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.label2.Location = new System.Drawing.Point(324, 58);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 39);
            this.label2.TabIndex = 5;
            this.label2.Text = ":";
            // 
            // timer
            // 
            this.timer.Interval = 1000;
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // OknoHodiny
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 160);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.poleSekundy);
            this.Controls.Add(this.poleMinuty);
            this.Controls.Add(this.tlačítkoNastav);
            this.Controls.Add(this.poleHodiny);
            this.Name = "OknoHodiny";
            this.Text = "Hodiny";
            this.Load += new System.EventHandler(this.OknoHodiny_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox poleHodiny;
        private System.Windows.Forms.Button tlačítkoNastav;
        private System.Windows.Forms.TextBox poleMinuty;
        private System.Windows.Forms.TextBox poleSekundy;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Timer timer;
    }
}

