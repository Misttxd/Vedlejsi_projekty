﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hodiny
{
    public partial class OknoHodiny : Form
    {
        public OknoHodiny()
        {
            InitializeComponent();
        }
        int sekundy = 0;
        int minuty = 0;
        int hodiny = 0;

        private void OknoHodiny_Load(object sender, EventArgs e)
        {
            timer.Enabled = true;   
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            sekundy++;
            if ((sekundy == 60) && (minuty == 59) && (hodiny == 23))
            {
                sekundy = 0;
                minuty = 0;
                hodiny = 0;
            }
            if (sekundy == 60)
            {
                minuty++;
                sekundy = 0;
            }

            if (minuty == 60)
            {
                hodiny++;
                minuty = 0;
            }

            poleHodiny.Text = hodiny.ToString();
            poleMinuty.Text = minuty.ToString();
            poleSekundy.Text = sekundy.ToString();  
        }

        private void tlačítkoNastav_Click(object sender, EventArgs e)
        {
            try
            {
                if (timer.Enabled == true)
                {
                    timer.Enabled = false;
                    poleHodiny.Enabled = true;
                    poleMinuty.Enabled = true;
                    poleSekundy.Enabled = true;
                    tlačítkoNastav.Text = "Start";
                }
                else
                {
                    timer.Enabled = true;
                    poleHodiny.Enabled = false;
                    poleMinuty.Enabled = false;
                    poleSekundy.Enabled = false;
                    sekundy = Convert.ToInt32(poleSekundy.Text);
                    minuty = Convert.ToInt32(poleMinuty.Text);
                    hodiny = Convert.ToInt32(poleHodiny.Text);
                    if ((sekundy > 59) || (sekundy < 0) ||  (minuty > 59) || (minuty < 0) || (hodiny > 23) || (hodiny < 0))
                    {
                        timer.Enabled = false;
                        tlačítkoNastav.Text = "Start";
                        poleHodiny.Enabled = true;
                        poleMinuty.Enabled = true;
                        poleSekundy.Enabled = true;
                        MessageBox.Show("Špatně zadané hodnoty, sekundy - rozsah 0 až 59, minuty - rozsah 0 až 59, hodiny - rozsah 0 až 23");
                     }
                    tlačítkoNastav.Text = "Nastav";
                }
            }
            catch (Exception)
            {
                timer.Enabled = false;
                tlačítkoNastav.Text = "Start";
                poleHodiny.Enabled = true;
                poleMinuty.Enabled = true;
                poleSekundy.Enabled = true;
                MessageBox.Show("Špatně zadané hodnoty, sekundy - rozsah 0 až 59, minuty - rozsah 0 až 59, hodiny - rozsah 0 až 23");
            }

        }
    }
}
