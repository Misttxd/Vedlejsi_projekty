﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SlideShow
{
    public partial class oknoSlideShow : Form
    {
        public oknoSlideShow()
        {
            InitializeComponent();
        }

        Image obrázek = null;
        int čísloObrázku = 0;

        private void oknoSlideShow_Load(object sender, EventArgs e)
        {

        }

        private void timer_Tick(object sender, EventArgs e)
        {
            čísloObrázku++;
            if (čísloObrázku == 6)
            {
                čísloObrázku = 1;
            }
            string jménoSouboru = "spszr" + čísloObrázku.ToString() + ".jpg";
            obrázek = Image.FromFile(jménoSouboru);

            Refresh();
        }

        private void oknoSlideShow_Paint(object sender, PaintEventArgs e)
        {
            Graphics kp = e.Graphics;
            if (obrázek != null)
            {
                kp.DrawImage(obrázek, 0, 0, 200, 200);
            }
        }
    }
}
