﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pohyb_tlačítka
{
    public partial class oknoPohybTlačítka : Form
    {
        public oknoPohybTlačítka()
        {
            InitializeComponent();
        }

        private void pohyblivéTlačítko_Click(object sender, EventArgs e)
        {
            timer.Enabled = !timer.Enabled;
        }

        private void timer_Tick(object sender, EventArgs e)
        {
            pohyblivéTlačítko.Top += 5;
        }
    }
}
