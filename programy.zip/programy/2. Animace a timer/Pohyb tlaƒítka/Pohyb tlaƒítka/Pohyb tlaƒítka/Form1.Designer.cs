﻿namespace Pohyb_tlačítka
{
    partial class oknoPohybTlačítka
    {
        /// <summary>
        /// Vyžaduje se proměnná návrháře.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Uvolněte všechny používané prostředky.
        /// </summary>
        /// <param name="disposing">hodnota true, když by se měl spravovaný prostředek odstranit; jinak false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Kód generovaný Návrhářem Windows Form

        /// <summary>
        /// Metoda vyžadovaná pro podporu Návrháře - neupravovat
        /// obsah této metody v editoru kódu.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.pohyblivéTlačítko = new System.Windows.Forms.Button();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // pohyblivéTlačítko
            // 
            this.pohyblivéTlačítko.Location = new System.Drawing.Point(61, 38);
            this.pohyblivéTlačítko.Name = "pohyblivéTlačítko";
            this.pohyblivéTlačítko.Size = new System.Drawing.Size(101, 42);
            this.pohyblivéTlačítko.TabIndex = 0;
            this.pohyblivéTlačítko.Text = "Tlačítko";
            this.pohyblivéTlačítko.UseVisualStyleBackColor = true;
            this.pohyblivéTlačítko.Click += new System.EventHandler(this.pohyblivéTlačítko_Click);
            // 
            // timer
            // 
            this.timer.Tick += new System.EventHandler(this.timer_Tick);
            // 
            // oknoPohybTlačítka
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(220, 548);
            this.Controls.Add(this.pohyblivéTlačítko);
            this.Name = "oknoPohybTlačítka";
            this.Text = "Pohyb tlačítka";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button pohyblivéTlačítko;
        private System.Windows.Forms.Timer timer;
    }
}

